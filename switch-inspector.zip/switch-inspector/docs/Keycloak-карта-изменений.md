# Подключение Keycloak: что и где менять

Перечень файлов с точками изменения. Составлен по фактическому коду.

**Предварительно выполнено:** схема базы, единая точка проверки личности,
разделение частей интерфейса — см. [План перехода](План-перехода-на-Keycloak.md).

---

## Сводка

| Файл | Объём изменений |
|---|---|
| `backend/server.js` | Основная работа: настройки, два адреса, обмен кода |
| `.env.example` | Четыре переменные |
| `deploy/kubernetes/02-configmap.yaml` | Адрес поставщика |
| `deploy/kubernetes/01-secret.example.yaml` | Секрет клиента |
| `frontend/src/components/Login/LoginScreen.jsx` | Кнопка входа |
| `frontend/src/store/slices/authSlice.js` | Обработка возврата |
| `frontend/src/features/users/UsersModal.jsx` | Удаление частей с паролями — на последнем этапе |

Изменения в базе **не требуются** — подготовка выполнена.

---

## 1. `backend/server.js`

### 1.1. Настройки поставщика

**Где:** рядом с настройками Яндекс ID, около строки 655.

```javascript
// ── Корпоративный поставщик учётных записей ──────────────────────────────
// Адреса берутся из документа настроек поставщика, который отдаётся
// по .well-known/openid-configuration — запрашивать его при каждом
// запуске не требуется, значения меняются крайне редко.
const OIDC_ISSUER = process.env.OIDC_ISSUER;
const OIDC_CLIENT_ID = process.env.OIDC_CLIENT_ID;
const OIDC_CLIENT_SECRET = process.env.OIDC_CLIENT_SECRET;
const OIDC_REDIRECT_URI = process.env.OIDC_REDIRECT_URI || (APP_URL + '/api/auth/oidc/callback');

// Создавать ли учётную запись при первом входе. Решение принимается
// до внедрения — см. план перехода.
const OIDC_AUTO_CREATE = process.env.OIDC_AUTO_CREATE === 'true';

const oidcEnabled = Boolean(OIDC_ISSUER && OIDC_CLIENT_ID && OIDC_CLIENT_SECRET);
if (!oidcEnabled) {
  console.warn('⚠ Корпоративный вход не настроен — доступен только вход по паролю.');
}
```

### 1.2. Сообщить интерфейсу о доступности

**Где:** обработчик `/api/health`, около строки 1090.

Интерфейс должен знать, показывать ли кнопку корпоративного входа.

```javascript
app.get('/api/health', (req, res) => {
  res.json({ ok: true, oidcEnabled });
});
```

### 1.3. Начало входа

**Где:** рядом с `/api/yandex/link/start`, около строки 1290.

```javascript
// Начало входа: создаём разовое состояние и отдаём адрес поставщика.
// Пользователь на этом этапе неизвестен — его сообщит поставщик
// при возврате, поэтому в состоянии он не указывается.
app.get('/api/auth/oidc/start', async (req, res) => {
  if (!oidcEnabled) {
    return res.status(503).json({ error: 'Корпоративный вход не настроен на сервере' });
  }
  const state = await createOauthState('login', null);
  const params = new URLSearchParams({
    response_type: 'code',
    client_id: OIDC_CLIENT_ID,
    redirect_uri: OIDC_REDIRECT_URI,
    scope: 'openid profile',
    state,
  });
  res.json({ authUrl: `${OIDC_ISSUER}/protocol/openid-connect/auth?${params}`, state });
});
```

> Путь `/protocol/openid-connect/auth` — стандартный для Keycloak.
> Точное значение лучше взять из документа настроек поставщика.

### 1.4. Обмен кода на сведения о пользователе

**Где:** рядом с `yandexExchangeCodeForUid`, около строки 359.

По той же схеме, что уже работает для второго фактора.

```javascript
// Обмен кода на сведения о вошедшем. Два запроса: сначала получаем
// токен, затем по нему — данные пользователя.
async function oidcExchangeCode(code) {
  const tokenResponse = await fetch(`${OIDC_ISSUER}/protocol/openid-connect/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'authorization_code',
      code,
      redirect_uri: OIDC_REDIRECT_URI,
      client_id: OIDC_CLIENT_ID,
      client_secret: OIDC_CLIENT_SECRET,
    }),
  });
  if (!tokenResponse.ok) throw new Error('Поставщик не принял код авторизации');

  const { access_token } = await tokenResponse.json();

  const userResponse = await fetch(`${OIDC_ISSUER}/protocol/openid-connect/userinfo`, {
    headers: { Authorization: `Bearer ${access_token}` },
  });
  if (!userResponse.ok) throw new Error('Не удалось получить сведения о пользователе');

  const info = await userResponse.json();

  // sub — постоянный идентификатор, не меняется никогда.
  // preferred_username может измениться, поэтому связь строим по sub.
  return {
    externalId: info.sub,
    username: info.preferred_username || info.email || info.sub,
    displayName: info.name || info.preferred_username || info.sub,
  };
}
```

### 1.5. Обработка возврата

**Где:** рядом с `/api/auth/yandex/callback`, около строки 1330.

```javascript
app.get('/api/auth/oidc/callback', async (req, res) => {
  const { code, state, error } = req.query;
  const redirectBase = APP_URL + '/';

  if (error || !code || !state) {
    if (state) await completeOauthState(state, 'error', { code: 'error' });
    return res.redirect(redirectBase + '?oidc=error');
  }

  // Та же защита от повторной обработки, что и у второго фактора:
  // код не должен обмениваться дважды.
  const entry = await lockOauthStateForProcessing(state);
  if (!entry) return res.redirect(redirectBase + '?oidc=expired');

  let info;
  try {
    info = await oidcExchangeCode(code);
  } catch (e) {
    console.error('Обмен кода не удался:', e.message);
    await completeOauthState(state, 'error', { code: 'error' });
    return res.redirect(redirectBase + '?oidc=error');
  }

  // Ищем по постоянному идентификатору, а не по логину: логин мог
  // измениться, идентификатор — нет.
  let row = await db.get('SELECT * FROM users WHERE external_id = ?', info.externalId);

  if (!row) {
    // Возможен случай: запись заведена заранее с тем же логином, но
    // ещё не связана с поставщиком. Связываем.
    const byName = await db.get(
      `SELECT * FROM users WHERE username = ? AND auth_provider = 'external' AND external_id IS NULL`,
      info.username
    );
    if (byName) {
      await db.run('UPDATE users SET external_id = ? WHERE username = ?', info.externalId, byName.username);
      row = await db.get('SELECT * FROM users WHERE username = ?', byName.username);
    }
  }

  if (!row) {
    if (!OIDC_AUTO_CREATE) {
      await completeOauthState(state, 'error', { code: 'unknown_user' });
      return res.redirect(redirectBase + '?oidc=unknown');
    }
    // Новый человек: заводим с правом только просмотра. Права выше
    // назначаются вручную — автоматически их выдавать нельзя.
    await db.run(
      `INSERT INTO users (username, auth_provider, external_id, display_name, role, created_at)
       VALUES (?, 'external', ?, ?, 'viewer', ?)`,
      info.username, info.externalId, info.displayName, Date.now()
    );
    row = await db.get('SELECT * FROM users WHERE external_id = ?', info.externalId);
  }

  // Отображаемое имя поддерживаем в актуальном состоянии.
  if (row.display_name !== info.displayName) {
    await db.run('UPDATE users SET display_name = ? WHERE username = ?', info.displayName, row.username);
    row.display_name = info.displayName;
  }

  await recordLoginSuccess(req.ip, row.username);
  const sessionData = await issueSessionToken(row);
  await completeOauthState(state, 'done', sessionData);

  return res.redirect(redirectBase + '?oidcToken=' + encodeURIComponent(sessionData.token));
});
```

> **Замечание.** Передача токена в адресе повторяет уже существующее
> решение и унаследует его недостаток — попадание в журналы прокси
> (находка 7 в разборе защищённости). Разумно исправить оба места
> сразу: передавать разовый код обмена вместо токена.

---

## 2. `.env.example`

Добавить:

```bash
# ── Корпоративный вход ───────────────────────────────────────────
# Адрес области в Keycloak, например:
# https://keycloak.company.ru/realms/employees
OIDC_ISSUER=
OIDC_CLIENT_ID=
OIDC_CLIENT_SECRET=

# Заводить ли учётную запись при первом входе нового человека.
# true  — заводится автоматически с правом только просмотра
# false — вход отклоняется, пока запись не создадут вручную
OIDC_AUTO_CREATE=false
```

---

## 3. Манифесты развёртывания

### `deploy/kubernetes/02-configmap.yaml`

```yaml
  OIDC_ISSUER: "https://keycloak.company.ru/realms/employees"
  OIDC_CLIENT_ID: "switch-inspector"
  OIDC_AUTO_CREATE: "false"
```

### `deploy/kubernetes/01-secret.example.yaml`

Добавить в перечень и в команду создания:

```bash
kubectl create secret generic switch-inspector-secrets \
  --from-literal=JWT_SECRET="..." \
  --from-literal=PGPASSWORD="..." \
  --from-literal=OIDC_CLIENT_SECRET='<секрет клиента>'
```

### `deploy/kubernetes/06-networkpolicy.yaml`

Правила ограничивают входящие обращения, исходящие не затрагивают —
изменений не требуется. Но если в кластере действуют правила на
исходящий трафик, потребуется разрешить обращение к Keycloak.

---

## 4. `frontend/src/components/Login/LoginScreen.jsx`

Кнопка корпоративного входа над формой пароля.

```jsx
// Доступность корпоративного входа сообщает сервер: показывать
// кнопку, которая никуда не ведёт, хуже, чем не показывать вовсе.
const [oidcEnabled, setOidcEnabled] = useState(false);

useEffect(() => {
  api.get('/api/health')
    .then((data) => setOidcEnabled(Boolean(data.oidcEnabled)))
    .catch(() => { /* не удалось узнать — остаётся вход по паролю */ });
}, []);

async function startCorporateLogin() {
  try {
    const { authUrl } = await api.get('/api/auth/oidc/start');
    window.location.href = authUrl;
  } catch (error) {
    dispatch(setError(error.message));
  }
}
```

В разметке — над полями ввода:

```jsx
{oidcEnabled && (
  <>
    <button className={styles.submit} type="button" onClick={startCorporateLogin}>
      Войти по корпоративной учётной записи
    </button>
    <div className={styles.divider}>или по логину и паролю</div>
  </>
)}
```

---

## 5. `frontend/src/store/slices/authSlice.js`

Обработка возврата с токеном в адресе.

**Где:** рядом с восстановлением сессии.

```javascript
/**
 * Завершение корпоративного входа.
 *
 * Сервер возвращает браузер с токеном в адресе. Токен сразу
 * сохраняется, а адрес очищается — иначе он остался бы в истории
 * браузера и мог попасть в закладки.
 */
export function consumeLoginRedirect() {
  return (dispatch) => {
    const params = new URLSearchParams(window.location.search);
    const token = params.get('oidcToken') || params.get('yandexToken');
    if (!token) return;

    setToken(token);
    try {
      window.history.replaceState({}, '', window.location.pathname);
    } catch {
      /* в изолированных средах может быть недоступно */
    }
    dispatch(restoreSession());
  };
}
```

Вызывать в `App.jsx` до проверки сессии.

---

## 6. `frontend/src/features/users/UsersModal.jsx`

**Только на последнем этапе**, когда все переведены.

Удаляются две части целиком: `CreateUserForm` и `ResetPasswordButton`,
вместе с их вызовами в разметке. Назначение ролей и дивизионов
остаётся без изменений.

Вместо создания записи стоит показать пояснение: учётные записи
появляются при первом входе через корпоративного поставщика.

---

## Порядок работы

| Шаг | Что делается | Можно ли начать сейчас |
|---|---|---|
| 1 | Запрос в команду Keycloak | **Да** |
| 2 | Настройки и переменные | Да, значения подставить позже |
| 3 | Обмен кода и обработка возврата | Нужны данные клиента |
| 4 | Кнопка в интерфейсе | Да |
| 5 | Проверка на тестовой записи | Нужен доступ к Keycloak |
| 6 | Перевод пользователей | После проверки |
| 7 | Удаление частей с паролями | После перевода всех |

---

## Что проверить после подключения

- Вход проходит, роль и зона ответственности применяются
- Повторный вход находит ту же запись, а не создаёт вторую
- Смена логина в Keycloak не разрывает связь — проверяется изменением
  логина в Keycloak и повторным входом
- Прекращённая в Keycloak запись войти не может
- Вход по паролю у не переведённых продолжает работать
- При недоступности Keycloak вход по паролю остаётся возможен
