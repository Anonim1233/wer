# Запуск в Kubernetes

Пошаговое развёртывание приложения в кластере.

---

## Перед началом

### Что потребуется

| Что | Зачем |
|---|---|
| Доступ к кластеру и настроенный `kubectl` | Применение манифестов |
| Пространство имён | Отдельное для приложения |
| Хранилище образов | Куда складывать собранные образы |
| Права на создание объектов | Развёртывания, службы, секреты, точка входа |
| Доменное имя и сертификат | Доступ пользователей |

### Что уточнить у команды инфраструктуры

Эти значения зависят от конкретного кластера — без них развёртывание
не заработает или будет работать неправильно:

| Вопрос | Где используется | Почему важно |
|---|---|---|
| Класс хранилища | `00-postgres.yaml` | Без него том может не создаться |
| Подсеть входного контроллера | `02-configmap.yaml`, `TRUSTED_PROXY` | Иначе ограничение частоты станет общим на всех |
| Имя пространства входного контроллера | `06-networkpolicy.yaml` | Иначе правила заблокируют доступ |
| Имя класса точки входа | `05-ingress.yaml` | Маршрутизация не заработает |
| Как выпускаются сертификаты | `05-ingress.yaml` | Доступ по защищённому соединению |
| Есть ли управляемая база данных | `00-postgres.yaml` | Если есть — лучше использовать её |

> **О базе данных.** Манифест `00-postgres.yaml` разворачивает базу
> в самом кластере. Если в компании есть управляемая служба баз данных,
> используйте её: она даёт резервное копирование и восстановление без
> вашего участия. Тогда этот файл не применяется, а в настройках
> указывается внешний адрес.

---

## Шаг 1. Сборка и публикация образов

```bash
cd switch-inspector

REGISTRY=registry.example.ru/switch-inspector
VERSION=1.0.0

docker build -t $REGISTRY/backend:$VERSION ./backend
docker build -t $REGISTRY/frontend:$VERSION ./frontend

docker push $REGISTRY/backend:$VERSION
docker push $REGISTRY/frontend:$VERSION
```

> **Проверьте архитектуру.** Если собираете на компьютере с процессором
> Apple, образы получатся под другую архитектуру и в кластере не
> запустятся. Собирайте с явным указанием:
> ```bash
> docker build --platform linux/amd64 -t $REGISTRY/backend:$VERSION ./backend
> ```

**Не используйте метку `latest`.** С ней невозможно понять, какая версия
работает, и откатиться к предыдущей.

---

## Шаг 2. Пространство имён

```bash
kubectl create namespace switch-inspector
kubectl config set-context --current --namespace=switch-inspector
```

---

## Шаг 3. Секреты

Создаются командой, а не файлом: значения не должны попадать
в репозиторий.

```bash
kubectl create secret generic switch-inspector-secrets \
  --from-literal=JWT_SECRET="$(openssl rand -hex 48)" \
  --from-literal=PGPASSWORD="$(openssl rand -base64 24)" \
  --from-literal=YANDEX_CLIENT_ID='<идентификатор>' \
  --from-literal=YANDEX_CLIENT_SECRET='<секрет>'
```

Проверить, что создан:
```bash
kubectl get secret switch-inspector-secrets
```

> **Ключ подписи должен быть одинаковым у всех копий приложения.**
> Он хранится в одном секрете, поэтому это выполняется само собой.
> Но если когда-нибудь потребуется его сменить — все пользователи
> будут разлогинены, это ожидаемо.

Для доступа к хранилищу образов может понадобиться отдельный секрет:
```bash
kubectl create secret docker-registry registry-credentials \
  --docker-server=registry.example.ru \
  --docker-username='<логин>' \
  --docker-password='<пароль>'
```

---

## Шаг 4. Настройки

```bash
nano deploy/kubernetes/02-configmap.yaml
```

Заполнить под свою среду:

```yaml
data:
  APP_URL: "https://switch-inspector.company.ru"   # реальный адрес
  TRUSTED_PROXY: "10.0.0.0/8"                      # подсеть входного контроллера
```

> `APP_URL` должен точно совпадать с адресом, по которому пользователи
> открывают приложение. От него зависят разрешённый источник запросов
> и адрес возврата при входе через внешнего поставщика.

Применить:
```bash
kubectl apply -f deploy/kubernetes/02-configmap.yaml
```

---

## Шаг 5. База данных

Если разворачиваете базу в кластере:

```bash
kubectl apply -f deploy/kubernetes/00-postgres.yaml
kubectl rollout status statefulset/postgres
```

Дождаться готовности:
```bash
kubectl get pods -l component=database
```

Состояние должно быть `Running`, готовность `1/1`.

### Создание схемы

Схема создаётся приложением при первом запуске — отдельных действий
не требуется. Если предпочитаете подготовить её заранее:

```bash
kubectl exec -it postgres-0 -- psql -U switch_inventory -d switch_inventory
```
и выполнить содержимое `database/01-schema.sql` и `02-indexes.sql`.

---

## Шаг 6. Приложение

Указать свои образы в манифестах:

```bash
sed -i "s|switch-inspector/backend:latest|$REGISTRY/backend:$VERSION|" \
  deploy/kubernetes/03-backend.yaml
sed -i "s|switch-inspector/frontend:latest|$REGISTRY/frontend:$VERSION|" \
  deploy/kubernetes/04-frontend.yaml
```

Применить:

```bash
kubectl apply -f deploy/kubernetes/03-backend.yaml
kubectl apply -f deploy/kubernetes/04-frontend.yaml

kubectl rollout status deployment/switch-inspector-backend
kubectl rollout status deployment/switch-inspector-frontend
```

Проверить:
```bash
kubectl get pods
```

Все поды должны быть `Running` с готовностью `1/1`.

---

## Шаг 7. Точка входа

```bash
nano deploy/kubernetes/05-ingress.yaml
```

Заменить `switch-inspector.example.ru` на реальный адрес, проверить имя
класса точки входа и способ получения сертификата.

```bash
kubectl apply -f deploy/kubernetes/05-ingress.yaml
kubectl get ingress
```

---

## Шаг 8. Ограничение сетевого доступа

```bash
nano deploy/kubernetes/06-networkpolicy.yaml
```

Проверить имя пространства входного контроллера, затем:

```bash
kubectl apply -f deploy/kubernetes/06-networkpolicy.yaml
```

> **Проверьте сразу после применения**, что приложение продолжает
> работать. Если имя пространства указано неверно, правила заблокируют
> обращения пользователей. Откатить:
> ```bash
> kubectl delete -f deploy/kubernetes/06-networkpolicy.yaml
> ```

> Правила действуют только если в кластере установлен сетевой модуль
> с их поддержкой. Если его нет, они будут приняты, но ни на что
> не повлияют.

---

## Шаг 9. Первый пользователь

```bash
kubectl exec -it deployment/switch-inspector-backend -- \
  node add-user.js admin '<надёжный пароль>' 'Администратор' developer
```

---

## Шаг 10. Проверка

```bash
# состояние всех частей
kubectl get pods,svc,ingress

# журнал сервера
kubectl logs -l component=backend --tail=50

# доступность изнутри кластера
kubectl exec deployment/switch-inspector-backend -- \
  node -e "fetch('http://127.0.0.1:3000/api/health').then(r=>r.json()).then(console.log)"
```

Открыть приложение по адресу и проверить:

| Что | Признак нормальной работы |
|---|---|
| Открытие | Страница входа по защищённому соединению |
| Вход | Выполняется, данные отображаются |
| Разделы | Все шесть открываются |
| Живые обновления | Правка в одном браузере видна в другом |
| Загрузка файла | Импорт из Excel проходит |
| Отчёт | PDF формируется, кириллица читается |

### Проверка настройки прокси

Важная проверка: работает ли определение адреса клиента.

```bash
kubectl logs -l component=backend --tail=100 | grep -i "429"
```

Если сразу после запуска появляются отказы с кодом 429 при обычной
работе — значит `TRUSTED_PROXY` указан неверно, и все клиенты
определяются как один адрес.

---

## Перенос данных из прежней версии

```bash
# копия базы с прежней площадки
scp <пользователь>@<прежний-сервер>:~/switch-inventory-backend/data.sqlite ./

# передать в под и выполнить перенос
kubectl cp data.sqlite $(kubectl get pod -l component=backend -o name | head -1 | cut -d/ -f2):/tmp/data.sqlite
kubectl exec deployment/switch-inspector-backend -- node migrate-to-postgres.js /tmp/data.sqlite
```

Скрипт выведет отчёт по каждой таблице. Исходный файл только читается.

Проверить количество записей:
```bash
kubectl exec postgres-0 -- psql -U switch_inventory -d switch_inventory -c \
  "SELECT 'switches' t, COUNT(*) FROM switches
   UNION ALL SELECT 'users', COUNT(*) FROM users
   UNION ALL SELECT 'cabinets', COUNT(*) FROM cabinets;"
```

---

## Обновление версии

```bash
VERSION=1.0.1
docker build -t $REGISTRY/backend:$VERSION ./backend
docker push $REGISTRY/backend:$VERSION

kubectl set image deployment/switch-inspector-backend backend=$REGISTRY/backend:$VERSION
kubectl rollout status deployment/switch-inspector-backend
```

Обновление идёт по одной копии: пользователи не замечают перерыва.

Откат:
```bash
kubectl rollout undo deployment/switch-inspector-backend
```

---

## Обслуживание

| Задача | Команда |
|---|---|
| Состояние | `kubectl get pods` |
| Журнал сервера | `kubectl logs -l component=backend --tail=100 -f` |
| Журнал базы | `kubectl logs postgres-0 --tail=50` |
| Подробности пода | `kubectl describe pod <имя>` |
| Перезапуск | `kubectl rollout restart deployment/switch-inspector-backend` |
| Изменить число копий | `kubectl scale deployment/switch-inspector-backend --replicas=3` |
| Консоль базы | `kubectl exec -it postgres-0 -- psql -U switch_inventory` |

### Резервное копирование

**Приложение копии не создаёт** — в контейнере они исчезли бы вместе
с ним. Копирование настраивается отдельно.

Разовая копия:
```bash
kubectl exec postgres-0 -- pg_dump -U switch_inventory -Fc switch_inventory > backup-$(date +%F).dump
```

Восстановление:
```bash
kubectl exec -i postgres-0 -- pg_restore -U switch_inventory -d switch_inventory --clean --if-exists < backup-2026-08-03.dump
```

Для регулярного копирования настраивается задание по расписанию —
это отдельная задача, которую стоит согласовать с командой
инфраструктуры.

---

## Если что-то пошло не так

### Под не запускается

```bash
kubectl describe pod <имя>
kubectl logs <имя> --previous
```

| Признак | Причина |
|---|---|
| `ImagePullBackOff` | Образ не найден или нет доступа к хранилищу |
| `CrashLoopBackOff` | Приложение падает при старте — смотреть журнал |
| `Pending` | Не хватает ресурсов или не создался том |
| `exec format error` | Образ собран под другую архитектуру процессора |

### Сервер не подключается к базе

```bash
kubectl logs -l component=backend --tail=30
kubectl get pods -l component=database
```

Проверить, что имя службы в настройках совпадает с именем в манифесте
базы, и что пароль в секрете тот же, с которым база создавалась.

> Если пароль меняли после первого запуска базы — она его не подхватит:
> пароль задаётся при создании хранилища. Потребуется изменить его
> изнутри базы либо пересоздать её.

### Приложение открывается, но запросы отклоняются

Значение `APP_URL` не совпадает с адресом в браузере.

```bash
kubectl get configmap switch-inspector-config -o yaml | grep APP_URL
```

После исправления перезапустить: настройки читаются при старте.

```bash
kubectl rollout restart deployment/switch-inspector-backend
```

### Отказы с кодом 429 при обычной работе

Неверный `TRUSTED_PROXY` — все клиенты определяются как один адрес.
Уточнить подсеть входного контроллера и исправить настройку.

### Данные пропали после перезапуска

Проверить, что том подключён:
```bash
kubectl get pvc
```

Если тома нет — база работала во временном хранилище, и данные
не сохранились. Это следствие неверного класса хранилища.

---

## Что осталось за рамками

| Область | Кто отвечает |
|---|---|
| Регулярное резервное копирование | Инфраструктура |
| Сбор журналов и наблюдение | Инфраструктура |
| Выпуск и продление сертификатов | Инфраструктура |
| Ограничение доступа к кластеру | Инфраструктура |
| Проверка образов на уязвимости | Конвейер сборки |

Приложение рассчитано на то, что эти задачи решаются на уровне
платформы, а не внутри него.
