-- ═══════════════════════════════════════════════════════════════════════
-- Switch Inspector — схема базы данных
--
-- Приложение создаёт схему само при первом запуске, поэтому выполнять
-- этот файл вручную не обязательно. Он нужен для:
--   • понимания структуры без чтения кода;
--   • ручной подготовки базы до запуска;
--   • согласования с администраторами баз данных.
--
-- Требуется PostgreSQL 13 или новее.
-- ═══════════════════════════════════════════════════════════════════════

-- ── Учётные записи ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id              SERIAL PRIMARY KEY,
  username        TEXT UNIQUE NOT NULL,

  -- Способ входа: local — собственный пароль, external — корпоративный
  -- поставщик учётных записей. Оба варианта сосуществуют: переход
  -- выполняется постепенно, а не одномоментно для всех.
  auth_provider   TEXT NOT NULL DEFAULT 'local',

  -- Пароль НЕ обязателен: у записей с внешним входом его нет вовсе.
  -- Обязательность обеспечивается ограничением users_auth_check ниже.
  password_hash   TEXT,

  -- Постоянный идентификатор из внешнего поставщика. Именно он, а не
  -- логин: логин может измениться (смена фамилии, перевод), а этот
  -- остаётся неизменным на всё время существования учётной записи.
  external_id     TEXT UNIQUE,

  -- Отображаемое имя приходит от корпоративного поставщика при входе
  -- и обновляется при каждом. Хранится как подсказка для интерфейса:
  -- показывать один идентификатор было бы неудобно.
  --
  -- Не обязательно: при отсутствии показывается идентификатор.
  -- Источником истины остаётся корпоративный каталог, не эта таблица.
  display_name    TEXT,
  role            TEXT NOT NULL DEFAULT 'admin',
  created_at      BIGINT NOT NULL,
  avatar          TEXT,          -- изображение в виде base64

  -- Учётная запись должна иметь ровно один рабочий способ входа:
  -- либо пароль, либо привязку к внешнему поставщику. Запись без
  -- того и другого войти не может и появляться не должна.
  CONSTRAINT users_auth_check CHECK (
    (auth_provider = 'local'    AND password_hash IS NOT NULL) OR
    (auth_provider = 'external' AND external_id   IS NOT NULL)
  )
);

COMMENT ON COLUMN users.auth_provider IS 'local | external';
COMMENT ON COLUMN users.external_id IS 'Постоянный идентификатор пользователя у внешнего поставщика';

COMMENT ON COLUMN users.role IS 'viewer | admin | developer';
COMMENT ON COLUMN users.avatar IS 'Хранится прямо в базе: файлов немного и они малы';

-- ── Зона ответственности ──────────────────────────────────────────────
-- Ограничение доступа по дивизионам, независимое от роли.
-- Пустой список означает доступ ко всем объектам.
CREATE TABLE IF NOT EXISTS user_divisions (
  username   TEXT NOT NULL,
  div_name   TEXT NOT NULL,
  PRIMARY KEY (username, div_name)
);

-- ── Коммутаторы ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS switches (
  mag               TEXT NOT NULL,   -- объект БЕЗ префикса: «134», не «MAG134»
  sw                TEXT NOT NULL,   -- имя С префиксом: «MAG134_70»
  shkaf             TEXT,            -- короткий код шкафа: «S3»
  ip                TEXT,
  up                TEXT,
  down_             TEXT,            -- с подчёркиванием: down — служебное слово
  location          TEXT,
  sn_netbox         TEXT,
  sn_lyra           TEXT,
  model             TEXT,
  comment           TEXT,
  comment_lyra      TEXT,
  updated_by        TEXT,
  updated_by_name   TEXT,
  updated_at        BIGINT NOT NULL,
  PRIMARY KEY (mag, sw)
);

COMMENT ON COLUMN switches.mag IS 'Объект без префикса — полный вид собирается приложением';
COMMENT ON COLUMN switches.sw IS 'Разделитель непостоянен: встречаются и MAG134_70, и MAG134-70';

-- ── Совместная работа ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notes (
  mag            TEXT NOT NULL,
  sw             TEXT NOT NULL,
  text           TEXT,
  -- Только идентификатор автора. Имя не дублируется: при смене
  -- фамилии копии разошлись бы с учётной записью, и в старых
  -- заметках осталась бы прежняя.
  username       TEXT REFERENCES users(username) ON DELETE SET NULL,
  updated_at     BIGINT,
  PRIMARY KEY (mag, sw)
);

CREATE TABLE IF NOT EXISTS statuses (
  mag            TEXT NOT NULL,
  sw             TEXT NOT NULL,
  done           INTEGER NOT NULL DEFAULT 1,
  username       TEXT REFERENCES users(username) ON DELETE SET NULL,
  updated_at     BIGINT,
  PRIMARY KEY (mag, sw)
);

COMMENT ON TABLE statuses IS 'Отметка «обработано». Наличие строки и есть отметка';

-- ── Дивизионы ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS divisions (
  name         TEXT PRIMARY KEY,
  created_at   BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS division_mags (
  div_name   TEXT NOT NULL,
  mag        TEXT NOT NULL,
  PRIMARY KEY (div_name, mag)
);

-- ── Шкафы ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cabinets (
  id               SERIAL PRIMARY KEY,
  mag              TEXT NOT NULL,
  name             TEXT NOT NULL,
  characteristic   TEXT,           -- обычно высота: «22U»
  location         TEXT,
  created_at       BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS cabinet_items (
  id           SERIAL PRIMARY KEY,
  cabinet_id   INTEGER NOT NULL REFERENCES cabinets(id) ON DELETE CASCADE,
  unit         INTEGER NOT NULL,
  name         TEXT,
  comment      TEXT,

  -- Ссылка на учтённый коммутатор, если позиция относится к нему.
  -- Заполняется при сохранении: приложение распознаёт имя в тексте
  -- и связывает записи. Пустая для пассивного оборудования —
  -- патч-панелей, органайзеров, оптики, которые в учёте не ведутся.
  --
  -- Связь именно ключом, а не сравнением имён при каждом обращении:
  -- переименование коммутатора не разрывает её, поиск идёт по индексу,
  -- а удаление учтённой записи не оставляет висящих ссылок.
  switch_mag   TEXT,
  switch_sw    TEXT,

  FOREIGN KEY (switch_mag, switch_sw)
    REFERENCES switches(mag, sw) ON DELETE SET NULL,

  -- Либо обе части ссылки заполнены, либо ни одной
  CONSTRAINT cabinet_items_switch_chk CHECK (
    (switch_mag IS NULL AND switch_sw IS NULL) OR
    (switch_mag IS NOT NULL AND switch_sw IS NOT NULL)
  )
);

COMMENT ON TABLE cabinet_items IS 'Сохранение заменяет содержимое шкафа целиком';
COMMENT ON COLUMN cabinet_items.switch_sw IS 'Ссылка на учтённый коммутатор; пусто для пассивного оборудования';

-- ── Состояние входа ───────────────────────────────────────────────────
-- Хранится в базе, а не в памяти процесса: при нескольких репликах
-- переход к провайдеру и возврат от него попадают на разные реплики.
CREATE TABLE IF NOT EXISTS oauth_states (
  state               TEXT PRIMARY KEY,
  purpose             TEXT NOT NULL,   -- link | verify | login

  -- Может быть пустым: при входе через корпоративного поставщика
  -- пользователь неизвестен до возврата — именно поставщик и сообщает,
  -- кто вошёл. Для link и verify заполняется всегда.
  username            TEXT,

  status              TEXT NOT NULL,   -- pending | processing | done | error
  result              TEXT,
  expires_at          BIGINT NOT NULL,
  result_expires_at   BIGINT
);

-- Счётчик неудачных попыток входа — тоже общий для всех реплик,
-- иначе допустимое число попыток умножалось бы на их количество.
CREATE TABLE IF NOT EXISTS login_attempts (
  ip         TEXT PRIMARY KEY,
  count      INTEGER NOT NULL,
  reset_at   BIGINT NOT NULL
);

-- ── Журнал действий ───────────────────────────────────────────────────
-- Фиксирует операции, меняющие данные — свои и чужие. Нужен, чтобы при
-- разбирательстве можно было установить, кто и что сделал: без него
-- ответа на такой вопрос не существует.
--
-- Особенно важен для отправки данных во внешние системы: там изменения
-- затрагивают чужую зону ответственности.
CREATE TABLE IF NOT EXISTS audit_log (
  id           SERIAL PRIMARY KEY,
  ts           BIGINT NOT NULL,
  username     TEXT NOT NULL,
  action       TEXT NOT NULL,   -- что сделано
  target       TEXT,            -- над чем
  details      TEXT,            -- подробности в свободной форме
  ip           TEXT
);

COMMENT ON COLUMN audit_log.action IS 'netbox_export | user_change | bulk_import | ...';

-- ── Состояние портов ──────────────────────────────────────────────────
-- Ночной срез с коммутаторов, соединённый с инвентаризацией компьютеров:
-- статус порта, VLAN, MAC-адреса и устройство за ними.
--
-- Шкаф, расположение и модель коммутатора сюда НЕ копируются: они ведутся
-- в учёте коммутаторов, и копия расходилась бы с ним.
CREATE TABLE IF NOT EXISTS port_status (
  mag            TEXT NOT NULL,
  sw             TEXT NOT NULL,
  port           INTEGER NOT NULL,
  sw_ip          TEXT,
  status         TEXT NOT NULL,      -- UP | DOWN | ADM (отключён администратором)
  speed          TEXT,
  vlan           TEXT,
  macs           TEXT,               -- через запятую; на одном порту их бывает несколько
  chassis_type   TEXT,
  manufacturer   TEXT,
  device_model   TEXT,
  machine_name   TEXT,
  primary_user   TEXT,               -- учётная запись LDAP, без ФИО
  snapshot_date  TEXT NOT NULL,      -- дата среза, ГГГГ-ММ-ДД
  imported_at    BIGINT NOT NULL,
  PRIMARY KEY (mag, sw, port)
);
