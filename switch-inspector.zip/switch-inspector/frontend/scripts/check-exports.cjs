#!/usr/bin/env node
/**
 * Проверка ввоза: всё, что модуль ввозит по имени из соседнего файла,
 * должно в том файле действительно экспортироваться.
 *
 * Зачем отдельно. Проверка синтаксиса этого не видит: модуль без нужной
 * функции синтаксически правилен. Ошибка всплывает только при сборке —
 * а в разработке и вовсе в браузере. Так однажды из модуля расчётов
 * главной страницы пропали три функции, и это обнаружилось уже
 * на сервере, при сборке образа.
 *
 * Использование: node scripts/check-exports.cjs [каталог=src]
 */
'use strict';
const fs = require('fs');
const path = require('path');

const root = process.argv[2] || 'src';
const EXT = ['', '.js', '.jsx', '/index.js', '/index.jsx'];

const walk = (dir) => fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
  const p = path.join(dir, e.name);
  if (e.isDirectory()) return e.name === 'node_modules' ? [] : walk(p);
  return /\.(js|jsx)$/.test(e.name) ? [p] : [];
});

const stripComments = (s) => s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:])\/\/.*$/gm, '$1');

const cache = new Map();
function exportsOf(file) {
  if (cache.has(file)) return cache.get(file);
  const src = stripComments(fs.readFileSync(file, 'utf8'));
  const names = new Set();
  let hasDefault = /\bexport\s+default\b/.test(src);
  for (const m of src.matchAll(/\bexport\s+(?:async\s+)?(?:function\*?|const|let|var|class)\s+([A-Za-z_$][\w$]*)/g)) names.add(m[1]);
  // export const { a, b } = slice.actions — так экспортируются действия хранилища
  for (const m of src.matchAll(/\bexport\s+(?:const|let|var)\s*\{([^}]*)\}\s*=/g)) {
    for (const part of m[1].split(',')) {
      const n = part.trim().split(':').pop().trim();
      if (n) names.add(n);
    }
  }
  for (const m of src.matchAll(/\bexport\s*\{([^}]*)\}(?!\s*=)/g)) {
    for (const part of m[1].split(',')) {
      const n = part.trim().split(/\s+as\s+/).pop().trim();
      if (n === 'default') hasDefault = true; else if (n) names.add(n);
    }
  }
  const result = { names, hasDefault };
  cache.set(file, result);
  return result;
}

const resolve = (from, spec) => {
  const base = path.resolve(path.dirname(from), spec);
  for (const ext of EXT) if (fs.existsSync(base + ext) && fs.statSync(base + ext).isFile()) return base + ext;
  return null;
};

let problems = 0;
let checked = 0;
for (const file of walk(root)) {
  const src = stripComments(fs.readFileSync(file, 'utf8'));
  // ввоз может занимать несколько строк — разбираем по всему тексту
  // Сначала разбираются ВСЕ ввозы, затем внешние отбрасываются: иначе
  // ввоз из библиотеки склеивался бы со следующим ввозом из своего файла.
  for (const m of src.matchAll(/\bimport\s+([^'";]*?)\s+from\s+['"]([^'"]+)['"]/g)) {
    const clause = m[1];
    const spec = m[2];
    if (!spec.startsWith('.')) continue;
    if (/\.(css|svg|png|jpe?g|json)$/.test(spec)) continue;
    const target = resolve(file, spec);
    if (!target) { console.log(`  ✗ ${file}: файл «${spec}» не найден`); problems++; continue; }
    const exp = exportsOf(target);
    if (/\*\s+as\s+/.test(clause)) continue;
    const named = clause.match(/\{([\s\S]*)\}/);
    const def = clause.replace(/\{[\s\S]*\}/, '').replace(/,/g, '').trim();
    if (def && !exp.hasDefault) { console.log(`  ✗ ${file}: в «${spec}» нет экспорта по умолчанию`); problems++; }
    if (named) {
      for (const part of named[1].split(',')) {
        const name = part.trim().split(/\s+as\s+/)[0].trim();
        if (!name) continue;
        checked++;
        if (name === 'default' ? !exp.hasDefault : !exp.names.has(name)) {
          console.log(`  ✗ ${file}: «${name}» не экспортируется из «${spec}»`);
          problems++;
        }
      }
    }
  }
}

console.log(problems
  ? `\nввоз с ошибками: ${problems}`
  : `\nвсе ввозы по имени на месте (проверено: ${checked})`);
process.exit(problems ? 1 : 0);
