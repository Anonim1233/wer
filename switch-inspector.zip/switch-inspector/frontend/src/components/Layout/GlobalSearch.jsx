/**
 * Глобальный поиск — по всей сети, а не в рамках одного объекта.
 *
 * Два источника:
 *   · коммутаторы — уже загружены в браузер, фильтруются мгновенно;
 *   · содержимое шкафов — запрос к серверу с задержкой, чтобы не
 *     обращаться к нему на каждое нажатие клавиши.
 *
 * Зона ответственности соблюдается в обоих: список коммутаторов
 * сервер отдаёт уже отфильтрованным, поиск по шкафам фильтрует сам.
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';

import { selectSwitches, selectPrefixMap } from '../../store/slices/switchesSlice';
import { objectLabel } from '../../domain/issues';
import { api } from '../../api/client';
import styles from './GlobalSearch.module.css';

const MIN_LENGTH = 2;
const MAX_SWITCHES = 15;
const CABINET_DELAY_MS = 300;

/** Поля, по которым ищется коммутатор — те же, что в прежней версии. */
const FIELDS = ['Коммутатор', 'IP Коммутатора', 'SN Netbox', 'SN Lyra', 'Расположение', 'Модель SW'];

export default function GlobalSearch() {
  const navigate = useNavigate();
  const switches = useSelector(selectSwitches);
  const prefixMap = useSelector(selectPrefixMap);

  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const [cabinets, setCabinets] = useState({ state: 'idle', rows: [] });
  const wrapRef = useRef(null);

  const trimmed = query.trim();
  const active = trimmed.length >= MIN_LENGTH;

  const switchResults = useMemo(() => {
    if (!active) return [];
    const q = trimmed.toLowerCase();
    return switches
      .filter((row) => FIELDS.some((f) => (row[f] || '').toLowerCase().includes(q)))
      .slice(0, MAX_SWITCHES);
  }, [switches, trimmed, active]);

  // Содержимое шкафов — с задержкой и отменой устаревших ответов:
  // иначе ответ на «DS25» мог бы прийти позже ответа на «DS253»
  // и затереть более точный результат.
  useEffect(() => {
    if (!active) {
      setCabinets({ state: 'idle', rows: [] });
      return undefined;
    }
    let cancelled = false;
    setCabinets((prev) => ({ ...prev, state: 'loading' }));
    const timer = setTimeout(async () => {
      try {
        const data = await api.get(`/api/cabinets/search?q=${encodeURIComponent(trimmed)}`);
        if (!cancelled) setCabinets({ state: 'ready', rows: data.results || [] });
      } catch {
        if (!cancelled) setCabinets({ state: 'error', rows: [] });
      }
    }, CABINET_DELAY_MS);
    return () => { cancelled = true; clearTimeout(timer); };
  }, [trimmed, active]);

  // Закрытие при щелчке вне поиска
  useEffect(() => {
    function handleClick(e) {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  function go(path) {
    setOpen(false);
    setQuery('');
    navigate(path);
  }

  return (
    <div className={styles.wrap} ref={wrapRef}>
      <input
        className={styles.input}
        type="search"
        placeholder="Поиск по всей сети…"
        value={query}
        onChange={(e) => { setQuery(e.target.value); setOpen(true); }}
        onFocus={() => setOpen(true)}
        onKeyDown={(e) => { if (e.key === 'Escape') { setOpen(false); e.currentTarget.blur(); } }}
        aria-label="Глобальный поиск"
      />

      {open && active && (
        <div className={styles.drop} role="listbox">
          <div className={styles.sectionTitle}>
            Коммутаторы{switchResults.length === MAX_SWITCHES ? ` — первые ${MAX_SWITCHES}` : ''}
          </div>
          {switchResults.length === 0 ? (
            <div className={styles.none}>Коммутаторы не найдены</div>
          ) : (
            switchResults.map((row) => (
              <button
                key={`${row['Mag']}__${row['Коммутатор']}`}
                className={styles.item}
                onClick={() => go(`/objects/${row['Mag']}/${row['Коммутатор']}`)}
              >
                <span className={styles.name}>{row['Коммутатор'] || '—'}</span>
                <span className={styles.sub}>
                  {objectLabel(row['Mag'], prefixMap)} · {row['IP Коммутатора'] || 'нет IP'} ·{' '}
                  {row['Расположение'] || 'нет расположения'}
                </span>
              </button>
            ))
          )}

          <div className={styles.sectionTitle}>В шкафах</div>
          {cabinets.state === 'loading' && <div className={styles.none}>Ищу…</div>}
          {cabinets.state === 'error' && <div className={styles.none}>Не удалось выполнить поиск</div>}
          {cabinets.state === 'ready' && cabinets.rows.length === 0 && (
            <div className={styles.none}>Ничего не найдено</div>
          )}
          {cabinets.state === 'ready' && cabinets.rows.map((row) => (
            <button
              key={`${row.cabinet_id}__${row.unit}`}
              className={styles.item}
              onClick={() => go(`/racks/${row.mag}/${row.cabinet_id}`)}
            >
              <span className={styles.name}>{row.name || '—'}</span>
              <span className={styles.sub}>
                {objectLabel(row.mag, prefixMap)} · {row.cabinet_name} · юнит {row.unit}
                {row.comment ? ` · ${row.comment}` : ''}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
