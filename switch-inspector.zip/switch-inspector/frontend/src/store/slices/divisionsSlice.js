/**
 * Дивизионы и их состав.
 *
 * Помимо самого справочника хранится обратная карта «объект → дивизион»:
 * по ней проверяется зона ответственности пользователя, и строить её
 * перебором при каждой проверке было бы накладно.
 */
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { api } from '../../api/client';

export const loadDivisions = createAsyncThunk('divisions/load', async (_, { rejectWithValue }) => {
  try {
    return await api.get('/api/divisions');
  } catch (error) {
    return rejectWithValue(error.message);
  }
});

const divisionsSlice = createSlice({
  name: 'divisions',
  initialState: { map: {}, magToDivision: {}, status: 'idle', error: null },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(loadDivisions.pending, (state) => { state.status = 'loading'; })
      .addCase(loadDivisions.fulfilled, (state, action) => {
        state.map = action.payload;
        const reverse = {};
        for (const [division, mags] of Object.entries(action.payload)) {
          for (const mag of mags) reverse[mag] = division;
        }
        state.magToDivision = reverse;
        state.status = 'ready';
      })
      .addCase(loadDivisions.rejected, (state, action) => {
        state.status = 'error';
        state.error = action.payload;
      });
  },
});


/**
 * Управление составом дивизионов.
 *
 * Все действия доступны только роли «разработчик» без ограничения
 * по зоне ответственности — иначе можно было бы расширить себе
 * доступ, добавив объект в свой дивизион.
 */
export const createDivision = createAsyncThunk(
  'divisions/create',
  async (name, { dispatch, rejectWithValue }) => {
    try {
      await api.post('/api/divisions', { name });
      await dispatch(loadDivisions());
      return name;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const deleteDivision = createAsyncThunk(
  'divisions/delete',
  async (name, { dispatch, rejectWithValue }) => {
    try {
      await api.delete(`/api/divisions/${encodeURIComponent(name)}`);
      await dispatch(loadDivisions());
      return name;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

/**
 * Назначение объекта дивизиону.
 *
 * Объект принадлежит одному дивизиону, поэтому при переносе он сначала
 * исключается из прежнего. Иначе он оказался бы в двух сразу, а зона
 * ответственности считалась бы по тому, который попался последним.
 *
 * Пустое значение division означает «убрать из дивизиона».
 */
export const assignMagToDivision = createAsyncThunk(
  'divisions/assignMag',
  async ({ mag, division }, { getState, dispatch, rejectWithValue }) => {
    const current = getState().divisions.magToDivision[mag];
    if (current === division) return { mag, division };

    try {
      if (current) {
        await api.delete(
          `/api/divisions/${encodeURIComponent(current)}/mags/${encodeURIComponent(mag)}`
        );
      }
      if (division) {
        await api.post(`/api/divisions/${encodeURIComponent(division)}/mags`, { mag });
      }
      await dispatch(loadDivisions());
      return { mag, division };
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export default divisionsSlice.reducer;

export const selectDivisions = (state) => state.divisions.map;
export const selectMagToDivision = (state) => state.divisions.magToDivision;

/** Право управлять составом дивизионов: роль «разработчик» и отсутствие
 *  ограничения по зоне. Совпадает с проверкой на сервере. */
export const selectCanManageDivisions = (state) => {
  const user = state.auth.user;
  if (!user || user.role !== 'developer') return false;
  return !user.scopeDivisions || user.scopeDivisions.length === 0;
};

/** Дивизион объекта либо null. */
export const selectDivisionOfMag = (state, mag) => state.divisions.magToDivision[mag] ?? null;
