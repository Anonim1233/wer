/**
 * Раскрытый коммутатор: лицевая панель с реальным состоянием портов
 * и список устройств на них.
 *
 * Плитка порта: заливка — статус, полоска снизу — цвет VLAN, тот же, что
 * на панели «Порты и VLAN» в карточке коммутатора. Порты, не подходящие
 * под выбранные фильтры, приглушаются, а не скрываются: так видно их место.
 */
import { useEffect, useState } from 'react';
import { api } from '../../api/client';
import { vlanColor } from '../../domain/ports';
import { STATUS_META, splitMacs } from '../../domain/portStatus';
import styles from './PortsPage.module.css';

const STATUS_CLASS = { UP: 'stUP', DOWN: 'stDOWN', ADM: 'stADM' };

export default function SwitchPorts({ mag, sw, vlan, status }) {
  const [data, setData] = useState({ state: 'loading', rows: [] });
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    let cancelled = false;
    api.get(`/api/ports/switch?mag=${encodeURIComponent(mag)}&sw=${encodeURIComponent(sw)}`)
      .then((r) => { if (!cancelled) setData({ state: 'ready', rows: r.rows }); })
      .catch((e) => { if (!cancelled) setData({ state: 'error', message: e.message, rows: [] }); });
    return () => { cancelled = true; };
  }, [mag, sw]);

  if (data.state === 'loading') return <div className={styles.expandNote}>Загружаю порты…</div>;
  if (data.state === 'error') return <div className={styles.expandNote}>{data.message}</div>;

  const matches = (p) => (!vlan || p.vlan === vlan) && (!status || p.status === status);
  const port = data.rows.find((p) => p.port === selected);
  const withDevices = data.rows.filter((p) => p.machine_name || p.macs);

  return (
    <div className={styles.expand}>
      <div className={styles.faceplate}>
        <div className={styles.faceGrid}>
          {data.rows.map((p) => (
            <button
              key={p.port}
              className={[styles.faceTile, styles[STATUS_CLASS[p.status]],
                matches(p) ? '' : styles.faceDim, selected === p.port ? styles.faceSel : ''].join(' ')}
              style={{ borderBottomColor: p.vlan ? vlanColor(p.vlan) : 'transparent' }}
              onClick={() => setSelected(selected === p.port ? null : p.port)}
              title={`Порт ${p.port} · ${STATUS_META[p.status].label}` +
                (p.vlan ? ` · VLAN ${p.vlan}` : '') + (p.machine_name ? ` · ${p.machine_name}` : '')}
            >
              {p.port}
            </button>
          ))}
        </div>
      </div>

      {port && (
        <div className={styles.portCard}>
          <b>Порт {port.port}</b> · {STATUS_META[port.status].label}
          {port.speed && <> · {port.speed}</>}
          {port.vlan && (
            <> · <span className={styles.vlanChip} style={{ '--vlan': vlanColor(port.vlan) }}>VLAN {port.vlan}</span></>
          )}
          {port.machine_name && (
            <div className={styles.portDevice}>
              {[port.chassis_type, port.manufacturer, port.device_model].filter(Boolean).join(' · ')}
              {' — '}<b>{port.machine_name}</b>{port.primary_user && <> · {port.primary_user}</>}
            </div>
          )}
          {port.macs && (
            <div className={styles.macs}>
              {splitMacs(port.macs).map((m) => <span key={m} className={styles.mac}>{m}</span>)}
            </div>
          )}
        </div>
      )}

      {withDevices.length > 0 && (
        <div className={styles.tableWrap}>
          <table className={styles.miniTable}>
            <thead>
              <tr><th>Порт</th><th>VLAN</th><th>MAC</th><th>Устройство</th><th>Имя</th><th>Пользователь</th></tr>
            </thead>
            <tbody>
              {withDevices.map((p) => (
                <tr key={p.port} className={selected === p.port ? styles.rowSel : ''} onClick={() => setSelected(p.port)}>
                  <td className={styles.num}>{p.port}</td>
                  <td>{p.vlan && <span className={styles.vlanChip} style={{ '--vlan': vlanColor(p.vlan) }}>{p.vlan}</span>}</td>
                  <td><div className={styles.macs}>{splitMacs(p.macs).map((m) => <span key={m} className={styles.mac}>{m}</span>)}</div></td>
                  <td>{[p.manufacturer, p.device_model].filter(Boolean).join(' ')}</td>
                  <td className={styles.mono}>{p.machine_name}</td>
                  <td className={styles.muted}>{p.primary_user}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
