/**
 * Вкладка «Порты»: ночной срез состояния портов по всей сети.
 *
 * Заменяет отчёт Power BI «Общая информация по коммутаторам on-line»
 * и «Устройства на портах коммутаторов». Сводку и поиск считает сервер:
 * по сети это десятки тысяч строк. Шкаф и расположение берутся из учёта
 * коммутаторов, а не из среза.
 */
import { Fragment, useEffect, useMemo, useRef, useState } from 'react';
import { useSelector } from 'react-redux';

import { api } from '../../api/client';
import { selectGrouped, selectPrefixMap } from '../../store/slices/switchesSlice';
import { selectDivisions } from '../../store/slices/divisionsSlice';
import { selectCanEdit } from '../../store/slices/authSlice';
import { objectLabel } from '../../domain/issues';
import { vlanColor } from '../../domain/ports';
import { STATUS_META, splitMacs, utilization } from '../../domain/portStatus';
import { usePortsImport } from './usePortsImport';
import SwitchPorts from './SwitchPorts';
import styles from './PortsPage.module.css';

const STATUS_CLASS = { UP: 'stUP', DOWN: 'stDOWN', ADM: 'stADM' };
const today = () => new Date().toISOString().slice(0, 10);
const formatDate = (iso) => (iso ? iso.split('-').reverse().join('.') : '—');

export default function PortsPage() {
  const grouped = useSelector(selectGrouped);
  const prefixMap = useSelector(selectPrefixMap);
  const divisions = useSelector(selectDivisions);
  const canEdit = useSelector(selectCanEdit);

  const [view, setView] = useState('switches');
  const [division, setDivision] = useState('');
  const [mag, setMag] = useState('');
  const [vlan, setVlan] = useState('');
  const [status, setStatus] = useState('');
  const [cabinet, setCabinet] = useState('');
  const [noLocation, setNoLocation] = useState(false);
  const [searchInput, setSearchInput] = useState('');
  const [q, setQ] = useState('');
  const [expanded, setExpanded] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);

  const [summary, setSummary] = useState({ state: 'loading' });
  const [devices, setDevices] = useState({ state: 'idle', rows: [] });

  const fileRef = useRef(null);
  const [snapshotDate, setSnapshotDate] = useState(today());
  const importer = usePortsImport(() => setReloadKey((k) => k + 1));

  // Поиск — с задержкой, чтобы не обращаться к серверу на каждую букву
  useEffect(() => {
    const t = setTimeout(() => setQ(searchInput.trim()), 300);
    return () => clearTimeout(t);
  }, [searchInput]);

  // Дивизион и объект отбираются на сервере — списком объектов
  const mags = useMemo(() => {
    if (mag) return [mag];
    if (division) return divisions[division] || [];
    return [];
  }, [mag, division, divisions]);

  const query = useMemo(() => {
    const p = new URLSearchParams();
    if (mags.length) p.set('mags', mags.join(','));
    if (vlan) p.set('vlan', vlan);
    if (status) p.set('status', status);
    if (q.length >= 2) p.set('q', q);
    return p.toString();
  }, [mags, vlan, status, q]);

  useEffect(() => {
    let cancelled = false;
    setSummary((s) => ({ ...s, state: s.data ? 'refreshing' : 'loading' }));
    api.get(`/api/ports/summary?${query}`)
      .then((data) => { if (!cancelled) setSummary({ state: 'ready', data }); })
      .catch((e) => { if (!cancelled) setSummary({ state: 'error', message: e.message }); });
    return () => { cancelled = true; };
  }, [query, reloadKey]);

  useEffect(() => {
    if (view !== 'devices') return undefined;
    let cancelled = false;
    setDevices((d) => ({ ...d, state: 'loading' }));
    api.get(`/api/ports/devices?${query}`)
      .then((data) => { if (!cancelled) setDevices({ state: 'ready', ...data }); })
      .catch((e) => { if (!cancelled) setDevices({ state: 'error', message: e.message, rows: [] }); });
    return () => { cancelled = true; };
  }, [view, query, reloadKey]);

  // Сведения из учёта: шкаф и расположение — по объекту и имени
  const inventory = useMemo(() => {
    const map = new Map();
    for (const [m, rows] of Object.entries(grouped)) {
      for (const r of rows) map.set(`${m}__${r['Коммутатор']}`, r);
    }
    return map;
  }, [grouped]);

  const data = summary.data;
  const enriched = useMemo(() => (data?.switches || []).map((s) => {
    const inv = inventory.get(`${s.mag}__${s.sw}`);
    return { ...s, cabinet: inv?.['Шкаф'] || '', location: inv?.['Расположение'] || '',
      model: inv?.['Модель SW'] || '', inInventory: Boolean(inv) };
  }), [data, inventory]);

  // Шкаф и «без расположения» — из учёта, поэтому отбираются здесь
  const visible = enriched.filter((s) =>
    (!cabinet || s.cabinet === cabinet) && (!noLocation || !s.location));

  const kpi = visible.reduce((a, s) => ({
    total: a.total + s.total, up: a.up + s.up, down: a.down + s.down,
    adm: a.adm + s.adm, devices: a.devices + s.devices,
  }), { total: 0, up: 0, down: 0, adm: 0, devices: 0 });
  const withoutLocation = enriched.filter((s) => !s.location).length;

  const objectOptions = [...new Set(enriched.map((s) => s.mag))].sort();
  const cabinetOptions = [...new Set(enriched.map((s) => s.cabinet).filter(Boolean))]
    .sort((a, b) => a.localeCompare(b, 'ru', { numeric: true }));
  const vlanOptions = [...(data?.vlans || [])].sort((a, b) => Number(a.vlan) - Number(b.vlan) || String(a.vlan).localeCompare(String(b.vlan)));

  const anyFilter = division || mag || vlan || status || cabinet || noLocation || searchInput;
  const resetFilters = () => {
    setDivision(''); setMag(''); setVlan(''); setStatus(''); setCabinet(''); setNoLocation(false); setSearchInput('');
  };

  const latest = data?.totals?.latest;
  const oldest = data?.totals?.oldest;
  const ageDays = latest ? Math.floor((Date.now() - new Date(latest).getTime()) / 86400000) : null;
  const nothingLoaded = summary.state === 'ready' && !anyFilter && !(data?.totals?.total);

  const statusCard = (key, value, extra) => (
    <button
      className={`${styles.kpi} ${styles.kpiButton} ${status === key ? styles.kpiActive : ''}`}
      onClick={() => setStatus(status === key ? '' : key)}
      title="Показать только такие порты"
    >
      <span className={`${styles.kpiDot} ${styles[STATUS_CLASS[key]]}`} />
      <span className={styles.kpiValue}>{value.toLocaleString('ru')}</span>
      <span className={styles.kpiLabel}>{STATUS_META[key].label}{extra}</span>
    </button>
  );

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <div className={styles.title}>Порты</div>
          <div className={styles.subtitle}>
            {latest ? (
              <>
                Срез на <b>{formatDate(latest)}</b>
                {oldest && oldest !== latest && <> · по части коммутаторов с {formatDate(oldest)}</>}
                {ageDays > 1 && <span className={styles.stale}> · сбор не приходил {ageDays} дн.</span>}
              </>
            ) : 'Срез ещё не загружен'}
          </div>
        </div>
        <div className={styles.spacer} />
        {canEdit && (
          <div className={styles.importBox}>
            <input
              type="date"
              className={styles.dateInput}
              value={snapshotDate}
              onChange={(e) => setSnapshotDate(e.target.value)}
              title="Дата среза"
            />
            <button className={styles.primary} onClick={() => fileRef.current?.click()}
              disabled={importer.state.status === 'reading' || importer.state.status === 'uploading'}>
              Загрузить срез
            </button>
            <input
              ref={fileRef} type="file" accept=".xlsx,.xls,.csv" hidden
              onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) importer.importFile(f, snapshotDate); }}
            />
          </div>
        )}
      </div>

      {importer.state.status !== 'idle' && (
        <div className={`${styles.importState} ${importer.state.status === 'error' ? styles.importError : ''}`}>
          <span>{importer.state.message}</span>
          {importer.state.status === 'uploading' && (
            <span className={styles.progress}><span style={{ width: `${importer.state.progress}%` }} /></span>
          )}
          {(importer.state.status === 'done' || importer.state.status === 'error') && (
            <button className={styles.linkButton} onClick={importer.reset}>Скрыть</button>
          )}
        </div>
      )}

      {summary.state === 'error' && <div className={styles.errorBox}>{summary.message}</div>}

      {nothingLoaded && (
        <div className={styles.empty}>
          <div className={styles.emptyTitle}>Срез портов ещё не загружен</div>
          <p>
            Загрузите выгрузку отчёта «Устройства на портах коммутаторов» в Excel или CSV.
            Нужны колонки <b>sw_name</b>, <b>Порты</b> и <b>Status</b>; остальные — VLAN, MAC,
            сведения об устройстве — подхватятся, если есть.
          </p>
        </div>
      )}

      {data && !nothingLoaded && (
        <>
          <div className={styles.kpiRow}>
            <div className={styles.kpi}>
              <span className={styles.kpiValue}>{kpi.total.toLocaleString('ru')}</span>
              <span className={styles.kpiLabel}>Портов</span>
            </div>
            {statusCard('UP', kpi.up, kpi.total ? ` · ${Math.round((kpi.up / kpi.total) * 100)}%` : '')}
            {statusCard('DOWN', kpi.down)}
            {statusCard('ADM', kpi.adm)}
            <div className={styles.kpi}>
              <span className={styles.kpiValue}>{(data.totals.vlans || 0).toLocaleString('ru')}</span>
              <span className={styles.kpiLabel}>VLAN в выборке</span>
            </div>
            <div className={styles.kpi}>
              <span className={styles.kpiValue}>{kpi.devices.toLocaleString('ru')}</span>
              <span className={styles.kpiLabel}>Устройств опознано</span>
            </div>
            <button
              className={`${styles.kpi} ${styles.kpiButton} ${noLocation ? styles.kpiActive : ''} ${withoutLocation ? styles.kpiWarn : ''}`}
              onClick={() => setNoLocation(!noLocation)}
              title="Показать коммутаторы без расположения в учёте"
            >
              <span className={styles.kpiValue}>{withoutLocation}</span>
              <span className={styles.kpiLabel}>Без расположения</span>
            </button>
          </div>

          <div className={styles.filters}>
            <select className={styles.select} value={division}
              onChange={(e) => { setDivision(e.target.value); setMag(''); }}>
              <option value="">Все дивизионы</option>
              {Object.keys(divisions).sort((a, b) => a.localeCompare(b, 'ru', { numeric: true }))
                .map((d) => <option key={d} value={d}>{d}</option>)}
            </select>
            <select className={styles.select} value={mag} onChange={(e) => setMag(e.target.value)}>
              <option value="">Все объекты</option>
              {objectOptions.map((m) => <option key={m} value={m}>{objectLabel(m, prefixMap)}</option>)}
            </select>
            <select className={styles.select} value={vlan} onChange={(e) => setVlan(e.target.value)}>
              <option value="">Все VLAN</option>
              {vlanOptions.map((v) => <option key={v.vlan} value={v.vlan}>VLAN {v.vlan} — {v.ports} порт.</option>)}
            </select>
            <select className={styles.select} value={cabinet} onChange={(e) => setCabinet(e.target.value)}>
              <option value="">Все шкафы</option>
              {cabinetOptions.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
            <div className={styles.segment}>
              {['', 'UP', 'DOWN', 'ADM'].map((s) => (
                <button key={s || 'all'} className={`${styles.segButton} ${status === s ? styles.segActive : ''}`}
                  onClick={() => setStatus(s)}>
                  {s || 'Все'}
                </button>
              ))}
            </div>
            <input
              className={styles.search} type="search" value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="MAC, имя компьютера, пользователь…"
            />
            {anyFilter && <button className={styles.linkButton} onClick={resetFilters}>Сбросить фильтры</button>}
          </div>

          <div className={styles.viewSwitch}>
            <button className={`${styles.viewButton} ${view === 'switches' ? styles.viewActive : ''}`}
              onClick={() => setView('switches')}>
              Коммутаторы <span className={styles.count}>{visible.length}</span>
            </button>
            <button className={`${styles.viewButton} ${view === 'devices' ? styles.viewActive : ''}`}
              onClick={() => setView('devices')}>
              Устройства
            </button>
            {summary.state === 'refreshing' && <span className={styles.muted}>обновляю…</span>}
          </div>

          {view === 'switches' && (
            <div className={styles.tableWrap}>
              <table className={styles.table}>
                <thead>
                  <tr>
                    <th>Объект</th><th>Коммутатор</th><th>Шкаф</th><th className={styles.hideMobile}>Расположение</th>
                    <th>Порты</th><th className={styles.hideMobile}>VLAN</th><th className={styles.hideMobile}>Устройств</th><th />
                  </tr>
                </thead>
                <tbody>
                  {visible.map((s) => {
                    const key = `${s.mag}__${s.sw}`;
                    const open = expanded === key;
                    return (
                      <Fragment key={key}>
                        <tr className={`${styles.swRow} ${open ? styles.swOpen : ''}`}
                          onClick={() => setExpanded(open ? null : key)}>
                          <td>{objectLabel(s.mag, prefixMap)}</td>
                          <td>
                            <div className={styles.mono}>{s.sw}</div>
                            <div className={styles.sub}>{s.sw_ip}</div>
                          </td>
                          <td>{s.cabinet || <span className={styles.muted}>—</span>}</td>
                          <td className={styles.hideMobile}>
                            {s.location || <span className={styles.warnChip}>не указано</span>}
                          </td>
                          <td>
                            <div className={styles.bar} title={`Поднято ${s.up} · не подключено ${s.down} · отключено ${s.adm}`}>
                              <span className={styles.stUP} style={{ width: `${(s.up / (s.total || 1)) * 100}%` }} />
                              <span className={styles.stDOWN} style={{ width: `${(s.down / (s.total || 1)) * 100}%` }} />
                              <span className={styles.stADM} style={{ width: `${(s.adm / (s.total || 1)) * 100}%` }} />
                            </div>
                            <div className={styles.sub}>{s.up} из {s.total} · {utilization(s)}%</div>
                          </td>
                          <td className={styles.hideMobile}>{s.vlans}</td>
                          <td className={styles.hideMobile}>{s.devices}</td>
                          <td className={styles.chevron}>{open ? '▴' : '▾'}</td>
                        </tr>
                        {open && (
                          <tr className={styles.expandRow}>
                            <td colSpan={8}>
                              <SwitchPorts mag={s.mag} sw={s.sw} vlan={vlan} status={status} />
                            </td>
                          </tr>
                        )}
                      </Fragment>
                    );
                  })}
                </tbody>
              </table>
              {visible.length === 0 && <div className={styles.none}>Под фильтры ничего не попало.</div>}
            </div>
          )}

          {view === 'devices' && (
            <>
              {devices.state === 'ready' && devices.total > devices.rows.length && (
                <div className={styles.note}>
                  Показано {devices.rows.length} из {devices.total.toLocaleString('ru')} — уточните фильтры или поиск.
                </div>
              )}
              {devices.state === 'error' && <div className={styles.errorBox}>{devices.message}</div>}
              <div className={styles.tableWrap}>
                <table className={styles.table}>
                  <thead>
                    <tr>
                      <th>Объект</th><th>Коммутатор</th><th>Порт</th><th>Статус</th><th>VLAN</th><th>MAC</th>
                      <th className={styles.hideMobile}>Устройство</th><th>Имя</th><th className={styles.hideMobile}>Пользователь</th>
                    </tr>
                  </thead>
                  <tbody>
                    {devices.rows
                      .filter((r) => {
                        const inv = inventory.get(`${r.mag}__${r.sw}`);
                        return (!cabinet || inv?.['Шкаф'] === cabinet) && (!noLocation || !inv?.['Расположение']);
                      })
                      .map((r) => (
                        <tr key={`${r.mag}__${r.sw}__${r.port}`}>
                          <td>{objectLabel(r.mag, prefixMap)}</td>
                          <td className={styles.mono}>{r.sw}</td>
                          <td className={styles.num}>{r.port}</td>
                          <td><span className={`${styles.pill} ${styles[STATUS_CLASS[r.status]]}`}>{r.status}</span></td>
                          <td>{r.vlan && <span className={styles.vlanChip} style={{ '--vlan': vlanColor(r.vlan) }}>{r.vlan}</span>}</td>
                          <td><div className={styles.macs}>{splitMacs(r.macs).map((m) => <span key={m} className={styles.mac}>{m}</span>)}</div></td>
                          <td className={styles.hideMobile}>{[r.chassis_type, r.manufacturer, r.device_model].filter(Boolean).join(' · ')}</td>
                          <td className={styles.mono}>{r.machine_name}</td>
                          <td className={`${styles.muted} ${styles.hideMobile}`}>{r.primary_user}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
                {devices.state === 'loading' && <div className={styles.none}>Загружаю…</div>}
                {devices.state === 'ready' && devices.rows.length === 0 && <div className={styles.none}>Ничего не найдено.</div>}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}
