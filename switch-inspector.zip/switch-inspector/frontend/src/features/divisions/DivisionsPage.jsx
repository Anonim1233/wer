/**
 * Раздел «Дивизионы»: рейтинг по заполненности данных.
 *
 * Дивизионы упорядочены от лучшего к худшему — так сразу видно,
 * где данные в порядке, а где требуется внимание.
 */
import { useMemo, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';

import { selectGrouped } from '../../store/slices/switchesSlice';
import {
  selectDivisions, selectCanManageDivisions, createDivision, deleteDivision,
} from '../../store/slices/divisionsSlice';
import { getAllDivisionStats } from '../../domain/divisions';
import Donut from '../../components/common/Donut';
import styles from './DivisionsPage.module.css';

/* Палитра сегментов. Цвета берутся по кругу, поэтому число дивизионов
   не ограничено размером списка. */
const PALETTE = [
  'var(--blue)', 'var(--ok)', 'var(--warn)', 'var(--purple)',
  'var(--cyan)', 'var(--orange)', 'var(--navy)', 'var(--slate)',
];

export default function DivisionsPage() {
  const grouped = useSelector(selectGrouped);
  const divisionMap = useSelector(selectDivisions);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const canManage = useSelector(selectCanManageDivisions);
  const [newName, setNewName] = useState('');
  const [error, setError] = useState(null);

  async function handleCreate() {
    const name = newName.trim();
    if (!name) return;
    setError(null);
    try {
      await dispatch(createDivision(name)).unwrap();
      setNewName('');
    } catch (message) {
      setError(String(message));
    }
  }

  async function handleDelete(name, objectCount) {
    const warning = objectCount > 0
      ? `Удалить дивизион «${name}»?\n\nОбъектов в нём: ${objectCount}. ` +
        'Они останутся в учёте, но перестанут относиться к какому-либо дивизиону.'
      : `Удалить дивизион «${name}»?`;
    if (!window.confirm(warning)) return;
    try {
      await dispatch(deleteDivision(name)).unwrap();
    } catch (message) {
      setError(String(message));
    }
  }

  const stats = useMemo(
    () => getAllDivisionStats(divisionMap, grouped),
    [divisionMap, grouped]
  );

  /* Для кольца дивизионы берутся по числу коммутаторов, а не по
     заполненности: диаграмма показывает распределение сети, а не
     качество данных — за него отвечает рейтинг ниже. */
  const segments = useMemo(
    () =>
      [...stats]
        .sort((a, b) => b.total - a.total)
        .map((s, i) => ({
          value: s.total,
          color: PALETTE[i % PALETTE.length],
          name: s.division,
        })),
    [stats]
  );

  const totalSwitches = segments.reduce((sum, s) => sum + s.value, 0);

  // Форма добавления вынесена отдельно: она нужна и в пустом состоянии.
  // Прежде при пустом справочнике страница показывала только заглушку,
  // и первый дивизион завести было негде.
  const addForm = (
    <>
      {canManage && (
        <div className={styles.addRow}>
          <input
            className={styles.addInput}
            placeholder="Название нового дивизиона"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') handleCreate(); }}
          />
          <button className={styles.addButton} onClick={handleCreate} disabled={!newName.trim()}>
            Добавить дивизион
          </button>
        </div>
      )}
      {error && <div className={styles.error}>{error}</div>}
    </>
  );

  if (!stats.length) {
    return (
      <div className={styles.page}>
        <div className={styles.section}>
          <div className={styles.emptyTitle}>Дивизионов пока нет</div>
          <p className={styles.emptyText}>
            {canManage
              ? 'Заведите первый дивизион, затем назначайте объекты: откройте объект и выберите ' +
                'дивизион рядом с его названием.'
              : 'Дивизионы заводит разработчик. Пока их нет, рейтинг и зоны ответственности не действуют.'}
          </p>
          {addForm}
        </div>
      </div>
    );
  }

  return (
    <div className={styles.page}>
      <div className={styles.top}>
        <div className={styles.topLabel}>Распределение по дивизионам</div>
        <div className={styles.summary}>
          <Donut segments={segments} size={72} label={String(totalSwitches)} />
          <div className={styles.legend}>
            {segments.map((segment) => (
              <div className={styles.legendItem} key={segment.name}>
                <span className={styles.swatch} style={{ background: segment.color }} />
                <span className={styles.legendName}>{segment.name}</span>
                <span className={styles.legendValue}>{segment.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className={styles.section}>
        {addForm}

        <div className={styles.sectionTitle}>Рейтинг по заполненности</div>
        <div className={styles.grid}>
          {stats.map((item, index) => (
            <DivisionCard
              key={item.division}
              stats={item}
              rank={index + 1}
              isLast={index >= stats.length - 3}
              onClick={() => navigate(`/divisions/${encodeURIComponent(item.division)}`)}
              onDelete={canManage ? () => handleDelete(item.division, item.mags.length) : null}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function DivisionCard({ stats, rank, isLast, onClick, onDelete }) {
  const rankClass =
    rank <= 3 ? styles.rankTop : isLast ? styles.rankLow : '';

  return (
    <div className={styles.card} onClick={onClick}>
      <span className={`${styles.rank} ${rankClass}`}>{rank}</span>
      {onDelete && (
        <button
          className={styles.cardDelete}
          onClick={(e) => { e.stopPropagation(); onDelete(); }}
          title="Удалить дивизион"
          aria-label={`Удалить дивизион ${stats.division}`}
        >
          ×
        </button>
      )}
      <div className={styles.cardName}>{stats.division}</div>
      <div className={styles.cardRow}>
        <Donut
          segments={[
            { value: stats.total - stats.issues, color: 'var(--ok)' },
            { value: stats.issues, color: 'var(--err)' },
          ]}
          size={54}
          label={`${stats.completion}%`}
        />
        <div className={styles.cardStats}>
          <div>
            Объектов: <span className={styles.cardStatValue}>{stats.mags.length}</span>
          </div>
          <div>
            Коммутаторов: <span className={styles.cardStatValue}>{stats.total}</span>
          </div>
          <div>
            С замечаниями: <span className={styles.cardStatValue}>{stats.issues}</span>
          </div>
          <div>
            Без SN Lyra:{' '}
            <span className={`${styles.cardStatValue} ${stats.noLyra ? styles.cardStatWarn : ''}`}>
              {stats.noLyra}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
