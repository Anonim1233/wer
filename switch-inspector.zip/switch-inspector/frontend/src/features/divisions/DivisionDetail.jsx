/**
 * Состав дивизиона: объекты с показателями заполненности.
 *
 * Открывается по выбору дивизиона в рейтинге. Отвечает на вопрос
 * «что внутри и за что браться», поэтому объекты по умолчанию
 * упорядочены от худших по заполненности.
 */
import { useMemo, useState } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';

import { selectGrouped, selectPrefixMap } from '../../store/slices/switchesSlice';
import { selectDivisions } from '../../store/slices/divisionsSlice';
import { getDivisionStats, hasNoLyra, percent } from '../../domain/divisions';
import { objectLabel } from '../../domain/issues';
import Donut from '../../components/common/Donut';
import styles from './DivisionDetail.module.css';

export default function DivisionDetail() {
  const { name } = useParams();
  const navigate = useNavigate();

  const grouped = useSelector(selectGrouped);
  const divisionMap = useSelector(selectDivisions);
  const prefixMap = useSelector(selectPrefixMap);

  const [sort, setSort] = useState('completion');

  const division = decodeURIComponent(name || '');
  const mags = divisionMap[division];

  const stats = useMemo(
    () => (mags ? getDivisionStats(division, mags, grouped) : null),
    [division, mags, grouped]
  );

  const objects = useMemo(() => {
    if (!mags) return [];
    const list = mags.map((mag) => {
      const rows = grouped[mag] ?? [];
      const issues = rows.filter((r) => r._issues > 0).length;
      const noLyra = rows.filter(hasNoLyra).length;
      return {
        mag,
        label: objectLabel(mag, prefixMap),
        total: rows.length,
        issues,
        noLyra,
        completion: percent(rows.length - issues, rows.length),
      };
    });

    // По умолчанию — от худших: раздел нужен, чтобы понять,
    // где хуже всего, а не пролистывать благополучные объекты.
    if (sort === 'completion') return list.sort((a, b) => a.completion - b.completion);
    if (sort === 'noLyra') return list.sort((a, b) => b.noLyra - a.noLyra);
    if (sort === 'size') return list.sort((a, b) => b.total - a.total);
    return list.sort((a, b) => a.label.localeCompare(b.label, 'ru', { numeric: true }));
  }, [mags, grouped, prefixMap, sort]);

  if (!mags) {
    return (
      <div className={styles.page}>
        <div className={styles.empty}>
          Дивизион «{division}» не найден.
          <button className={styles.link} onClick={() => navigate('/divisions')}>
            Вернуться к списку
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.page}>
      <div className={styles.top}>
        <button className={styles.back} onClick={() => navigate('/divisions')}>
          ← Все дивизионы
        </button>

        <div className={styles.summary}>
          <Donut
            segments={[
              { value: stats.total - stats.issues, color: 'var(--ok)' },
              { value: stats.issues, color: 'var(--err)' },
            ]}
            size={72}
            label={`${stats.completion}%`}
          />

          <div>
            <div className={styles.name}>{division}</div>
            <div className={styles.meta}>
              {stats.mags.length} объектов · {stats.total} коммутаторов
            </div>
          </div>

          <div className={styles.spacer} />

          <div className={styles.kpiRow}>
            <div className={styles.kpi}>
              <div className={styles.kpiValue}>{stats.total}</div>
              <div className={styles.kpiLabel}>Коммутаторов</div>
            </div>
            <div className={styles.kpi}>
              <div className={`${styles.kpiValue} ${stats.issues ? styles.warn : ''}`}>
                {stats.issues}
              </div>
              <div className={styles.kpiLabel}>С замечаниями</div>
            </div>
            <div className={styles.kpi}>
              <div className={`${styles.kpiValue} ${stats.noLyra ? styles.warn : ''}`}>
                {stats.noLyra}
              </div>
              <div className={styles.kpiLabel}>Без SN Lyra</div>
            </div>
          </div>
        </div>
      </div>

      <div className={styles.section}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTitle}>Объекты дивизиона</span>
          <select className={styles.select} value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="completion">Сначала худшие по заполненности</option>
            <option value="noLyra">Сначала с наибольшим числом без SN Lyra</option>
            <option value="size">Сначала крупные</option>
            <option value="name">По названию</option>
          </select>
        </div>

        <div className={styles.tableWrap}>
          <table className={styles.table}>
            <thead>
              <tr>
                <th>Объект</th>
                <th>Коммутаторов</th>
                <th>С замечаниями</th>
                <th>Без SN Lyra</th>
                <th>Заполненность</th>
              </tr>
            </thead>
            <tbody>
              {objects.map((item) => (
                <tr key={item.mag} onClick={() => navigate(`/objects/${item.mag}`)}>
                  <td>{item.label}</td>
                  <td>{item.total}</td>
                  <td className={item.issues ? styles.warn : ''}>{item.issues}</td>
                  <td className={item.noLyra ? styles.warn : ''}>{item.noLyra}</td>
                  <td>
                    <span className={styles.bar}>
                      <span
                        className={styles.fill}
                        style={{
                          width: `${item.completion}%`,
                          background: item.completion >= 95 ? 'var(--ok)'
                            : item.completion >= 80 ? 'var(--warn)' : 'var(--err)',
                        }}
                      />
                    </span>
                    {item.completion}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
