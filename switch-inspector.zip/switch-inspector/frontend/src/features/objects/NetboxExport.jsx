/**
 * Отправка данных объекта в NetBox.
 *
 * Три части, подтверждаемые отдельно: серийные номера, стойки
 * с размещением, заведение отсутствующих устройств. Сначала всегда
 * показывается, что именно изменится; после каждой отправки просмотр
 * обновляется сам — например, заведённые устройства сразу появляются
 * среди доступных для размещения.
 */
import { useCallback, useEffect, useState } from 'react';
import { api } from '../../api/client';
import styles from './NetboxExport.module.css';

const TABS = [
  { id: 'serials', label: 'Серийные номера' },
  { id: 'racks', label: 'Стойки и размещение' },
  { id: 'devices', label: 'Новые устройства' },
];

export default function NetboxExport({ mag, objectLabel, onClose }) {
  const [tab, setTab] = useState('serials');
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);
  const [includeMoves, setIncludeMoves] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setPlan(await api.get(`/api/netbox/export/preview?mag=${encodeURIComponent(mag)}`));
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [mag]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    function handleKey(e) { if (e.key === 'Escape' && !sending) onClose(); }
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [onClose, sending]);

  async function send(path, body, question) {
    if (!window.confirm(`${question}\n\nОбъект: ${objectLabel}`)) return;
    setSending(true);
    setError(null);
    setResult(null);
    try {
      const response = await api.post(path, { mag, ...body });
      setResult(response);
      await load();
    } catch (e) {
      setError(e.message);
    } finally {
      setSending(false);
    }
  }

  const serials = plan?.serials;
  const racks = plan?.racks;
  const devices = plan?.devices;
  const overwrites = serials?.toSend.filter((x) => x.overwrites).length ?? 0;
  const newRacks = racks?.racks.filter((r) => !r.existingId).length ?? 0;

  return (
    <>
      <button className={styles.overlay} onClick={() => !sending && onClose()} aria-label="Закрыть" />

      <div className={styles.modal} role="dialog" aria-label="Отправка в NetBox">
        <div className={styles.header}>
          <div>
            <div className={styles.title}>Отправка в NetBox</div>
            <div className={styles.subtitle}>{objectLabel}</div>
          </div>
          <div className={styles.spacer} />
          <button className={styles.close} onClick={onClose} disabled={sending} aria-label="Закрыть">×</button>
        </div>

        <div className={styles.tabs}>
          {TABS.map((t) => (
            <button
              key={t.id}
              className={`${styles.tab} ${tab === t.id ? styles.tabActive : ''}`}
              onClick={() => { setTab(t.id); setResult(null); }}
            >
              {t.label}
              {plan && <span className={styles.badge}>{countFor(t.id, plan)}</span>}
            </button>
          ))}
        </div>

        <div className={styles.body}>
          {loading && <div className={styles.intro}>Сверяю объект с NetBox…</div>}
          {error && <div className={styles.error}>{error}</div>}

          {plan && !plan.writeEnabled && (
            <div className={styles.warning}>
              Токен записи NetBox не задан на сервере — изменения можно только просмотреть.
            </div>
          )}

          {plan && plan.siteProblem && tab !== 'serials' && (
            <div className={styles.warning}>{plan.siteProblem}</div>
          )}

          {result && <ResultBox result={result} />}

          {/* ── Серийные номера ── */}
          {plan && !loading && tab === 'serials' && (
            <>
              <p className={styles.intro}>
                Источник истины — Лира. Значение из поля SN Lyra записывается в NetBox
                и перекрывает имеющееся.
              </p>
              {serials.toSend.length === 0 ? (
                <div className={styles.ok}>Расхождений нет — отправлять нечего.</div>
              ) : (
                <Table head={['Коммутатор', 'Было в NetBox', 'Станет']}>
                  {serials.toSend.map((x) => (
                    <tr key={x.sw} className={x.overwrites ? styles.rowWarn : ''}>
                      <td className={styles.mono}>{x.sw}</td>
                      <td className={styles.mono}>{x.oldSerial ?? <span className={styles.muted}>пусто</span>}</td>
                      <td className={styles.mono}>{x.newSerial}</td>
                    </tr>
                  ))}
                </Table>
              )}
              {overwrites > 0 && (
                <div className={styles.warning}>
                  Выделенные строки ({overwrites}) перезапишут значения, внесённые в NetBox ранее.
                </div>
              )}
              <Skipped items={[
                ['без серийника в Лире', serials.skipped.noSource],
                ['нет в NetBox', serials.skipped.notInNetbox],
                ['выведены из работы в NetBox', serials.skipped.inactive],
              ]} />
            </>
          )}

          {/* ── Стойки и размещение ── */}
          {plan && !loading && tab === 'racks' && (
            <>
              <p className={styles.intro}>
                Отправляются стойки и размещение коммутаторов. Пассивное оборудование —
                патч-панели, органайзеры — не отправляется: в NetBox стойка содержит
                устройства с моделью и производителем.
              </p>
              {racks.racks.length > 0 && (
                <Table head={['Стойка', 'Высота', 'В NetBox']}>
                  {racks.racks.map((r) => (
                    <tr key={r.name}>
                      <td>{r.name}</td>
                      <td>{r.height ? `${r.height}U` : <span className={styles.muted}>не указана</span>}</td>
                      <td>{r.existingId ? 'есть' : <b>будет создана</b>}</td>
                    </tr>
                  ))}
                </Table>
              )}
              {racks.placements.length > 0 && (
                <Table head={['Коммутатор', 'Стойка', 'Юнит', 'Было']}>
                  {racks.placements.map((x) => (
                    <tr key={x.sw}>
                      <td className={styles.mono}>{x.sw}</td>
                      <td>{x.rack}</td>
                      <td>{x.position}</td>
                      <td>{x.currentPosition != null ? `юнит ${x.currentPosition}` : <span className={styles.muted}>не размещён</span>}</td>
                    </tr>
                  ))}
                </Table>
              )}
              {racks.moves.length > 0 && (
                <>
                  <Table head={['Перенос', 'Из стойки', 'В стойку', 'Юнит']}>
                    {racks.moves.map((x) => (
                      <tr key={x.sw} className={styles.rowWarn}>
                        <td className={styles.mono}>{x.sw}</td>
                        <td>{x.currentRack}</td>
                        <td>{x.rack}</td>
                        <td>{x.position}</td>
                      </tr>
                    ))}
                  </Table>
                  {/* Перенос в другую стойку — существенное изменение,
                      поэтому включается отдельной отметкой */}
                  <label className={styles.checkbox}>
                    <input type="checkbox" checked={includeMoves} onChange={(e) => setIncludeMoves(e.target.checked)} />
                    Отправить и переносы между стойками ({racks.moves.length})
                  </label>
                </>
              )}
              {!newRacks && !racks.placements.length && !racks.moves.length && (
                <div className={styles.ok}>Размещение в NetBox совпадает с нашим.</div>
              )}
              <Skipped items={[['пропущено', racks.skipped.map((x) => `${x.sw} — ${x.reason}`)]]} />
            </>
          )}

          {/* ── Новые устройства ── */}
          {plan && !loading && tab === 'devices' && (
            <>
              <p className={styles.intro}>
                Коммутаторы, которые есть у нас, но отсутствуют в NetBox. Заводятся на площадке
                объекта с ролью из настроек сервера; тип подбирается по модели только при точном
                совпадении — угадывать по похожему названию нельзя. В комментарии NetBox
                отмечается, что запись заведена из Switch Inspector.
              </p>
              {devices.toCreate.length === 0 ? (
                <div className={styles.ok}>Заводить нечего.</div>
              ) : (
                <Table head={['Коммутатор', 'Тип в NetBox', 'Серийный номер']}>
                  {devices.toCreate.map((x) => (
                    <tr key={x.sw}>
                      <td className={styles.mono}>{x.sw}</td>
                      <td>{x.deviceTypeName}</td>
                      <td className={styles.mono}>{x.serial ?? <span className={styles.muted}>нет</span>}</td>
                    </tr>
                  ))}
                </Table>
              )}
              {devices.skipped.length > 0 && (
                <div className={styles.note}>
                  <b>Нельзя завести автоматически ({devices.skipped.length}):</b>
                  <ul className={styles.list}>
                    {devices.skipped.map((x) => <li key={x.sw}><span className={styles.mono}>{x.sw}</span> — {x.reason}</li>)}
                  </ul>
                </div>
              )}
              {devices.toCreate.length > 0 && (
                <div className={styles.note}>
                  После заведения устройства появятся во вкладке «Стойки и размещение».
                </div>
              )}
            </>
          )}
        </div>

        <div className={styles.footer}>
          {plan && plan.writeEnabled && !loading && tab === 'serials' && serials.toSend.length > 0 && (
            <button className={`${styles.button} ${styles.primary}`} disabled={sending}
              onClick={() => send('/api/netbox/export/serials', {},
                `Записать ${serials.toSend.length} серийных номеров в NetBox?` +
                (overwrites ? `\n\nИз них ${overwrites} ПЕРЕЗАПИШУТ прежние значения.` : ''))}>
              Отправить серийные номера
            </button>
          )}
          {plan && plan.writeEnabled && !loading && tab === 'racks' && !plan.siteProblem
            && (newRacks || racks.placements.length || (includeMoves && racks.moves.length)) > 0 && (
            <button className={`${styles.button} ${styles.primary}`} disabled={sending}
              onClick={() => send('/api/netbox/export/racks', { includeMoves },
                `Создать стоек: ${newRacks}\nРазместить устройств: ${racks.placements.length}` +
                (includeMoves && racks.moves.length ? `\nПЕРЕНЕСТИ между стойками: ${racks.moves.length}` : ''))}>
              Отправить размещение
            </button>
          )}
          {plan && plan.writeEnabled && !loading && tab === 'devices' && !plan.siteProblem && devices.toCreate.length > 0 && (
            <button className={`${styles.button} ${styles.primary}`} disabled={sending}
              onClick={() => send('/api/netbox/export/devices', {},
                `Завести в NetBox устройств: ${devices.toCreate.length}?`)}>
              Завести в NetBox
            </button>
          )}
          {sending && <span className={styles.subtitle}>Отправляю…</span>}
          <div className={styles.spacer} />
          <button className={styles.button} onClick={load} disabled={loading || sending}>Обновить</button>
          <button className={styles.button} onClick={onClose} disabled={sending}>Закрыть</button>
        </div>
      </div>
    </>
  );
}

function countFor(tab, plan) {
  if (tab === 'serials') return plan.serials.toSend.length;
  if (tab === 'racks') {
    return plan.racks.racks.filter((r) => !r.existingId).length
      + plan.racks.placements.length + plan.racks.moves.length;
  }
  return plan.devices.toCreate.length;
}

function Table({ head, children }) {
  return (
    <div className={styles.tableWrap}>
      <table className={styles.table}>
        <thead><tr>{head.map((h) => <th key={h}>{h}</th>)}</tr></thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}

function Skipped({ items }) {
  const filled = items.filter(([, list]) => list.length);
  if (!filled.length) return null;
  return (
    <div className={styles.note}>
      {filled.map(([label, list]) => (
        <div key={label}>Не отправляется, {label}: {list.length}</div>
      ))}
    </div>
  );
}

function ResultBox({ result }) {
  const parts = [];
  if (result.sent != null) parts.push(`отправлено: ${result.sent}`);
  if (result.overwritten) parts.push(`из них перезаписано: ${result.overwritten}`);
  if (result.racksCreated != null) parts.push(`создано стоек: ${result.racksCreated}`);
  if (result.placed != null) parts.push(`размещено: ${result.placed}`);
  if (result.created != null) parts.push(`заведено устройств: ${result.created}`);
  if (result.failed) parts.push(`не удалось: ${result.failed}`);
  return (
    <div className={result.failed ? styles.warning : styles.ok}>
      Готово — {parts.join(', ')}.
      {result.errors?.length > 0 && (
        <ul className={styles.list}>
          {result.errors.map((e, i) => <li key={i}>{e.объект}: {e.ошибка}</li>)}
        </ul>
      )}
    </div>
  );
}
