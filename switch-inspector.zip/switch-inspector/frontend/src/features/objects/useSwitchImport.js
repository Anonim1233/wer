/**
 * Загрузка коммутаторов из файла.
 *
 * Существующие записи обновляются, новые добавляются. Удаление строки
 * из файла запись НЕ удаляет — для этого есть отдельное действие
 * в карточке. Так задумано: файл может быть выгрузкой по части сети.
 */
import { useState } from 'react';
import { useDispatch } from 'react-redux';
import * as XLSX from 'xlsx';

import { api } from '../../api/client';
import { prepareSwitchRows, detectColumns } from '../../domain/switchImport';
import { sanitizeParsed, checkFileSize } from '../../domain/safeParse';
import { loadSwitches } from '../../store/slices/switchesSlice';

export function useSwitchImport() {
  const dispatch = useDispatch();
  const [state, setState] = useState({ status: 'idle' });

  async function importFile(file) {
    const sizeError = checkFileSize(file);
    if (sizeError) {
      setState({ status: 'error', message: sizeError });
      return;
    }

    setState({ status: 'parsing' });

    let parsed;
    let columns;
    try {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array' });

      // Данные могут лежать не на первом листе: в выгрузках встречаются
      // titular-листы и пояснения. Ищем лист, где есть нужные колонки,
      // и только если не нашли — берём первый.
      let raw = [];
      for (const sheetName of workbook.SheetNames) {
        const rows = sanitizeParsed(
          XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: '' })
        );
        if (!rows.length) continue;
        const check = detectColumns(rows);
        if (check.found.includes('Mag') && check.found.includes('Коммутатор')) {
          raw = rows;
          break;
        }
        if (!raw.length) raw = rows; // запасной вариант — первый непустой
      }

      columns = detectColumns(raw);
      parsed = prepareSwitchRows(raw);
    } catch {
      setState({ status: 'error', message: 'Не удалось прочитать файл.' });
      return;
    }

    if (!parsed.rows.length) {
      // Сообщение показывает, что именно нашлось в файле: без этого
      // причина неочевидна, и остаётся только гадать.
      const detail = columns?.actual?.length
        ? ` Найденные колонки: ${columns.actual.slice(0, 12).join(', ')}.`
        : ' Файл не содержит строк с данными.';

      setState({
        status: 'error',
        message:
          'В файле не найдено записей. Нужны колонки «Mag» и «Коммутатор» ' +
          '(регистр и лишние пробелы значения не имеют).' + detail,
      });
      return;
    }

    setState({ status: 'uploading' });

    try {
      const result = await api.post('/api/switches/bulk', { rows: parsed.rows });
      await dispatch(loadSwitches());

      let message = `Загружено записей: ${result.imported}.`;
      if (parsed.skipped) message += ` Пропущено без объекта или имени: ${parsed.skipped}.`;
      if (result.skippedOutOfScope) {
        message += ` Вне вашей зоны ответственности: ${result.skippedOutOfScope}.`;
      }

      setState({ status: 'done', message });
    } catch (error) {
      setState({ status: 'error', message: error.message });
    }
  }

  return { state, importFile };
}
