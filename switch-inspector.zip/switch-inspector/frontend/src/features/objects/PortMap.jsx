/**
 * Порты коммутатора и VLAN — в виде лицевой панели.
 *
 * Порты в два ряда, как на самом оборудовании: нечётные сверху, чётные
 * снизу. Цвет — VLAN доступа; транковые и отключённые порты выглядят
 * по-своему. Нажатие на порт — подробности, нажатие на VLAN в легенде —
 * подсветка портов, через которые он проходит.
 *
 * Данные — интерфейсы устройства в NetBox. Загружаются при раскрытии
 * блока, а не при открытии карточки, чтобы не обращаться к NetBox зря.
 */
import { useEffect, useMemo, useState } from 'react';
import { api } from '../../api/client';
import {
  groupPorts, portState, vlanColor, portCarriesVlan, summarizeVlans, splitPortName,
} from '../../domain/ports';
import styles from './PortMap.module.css';

const STATE_TEXT = {
  access: 'доступ',
  trunk: 'транк',
  'trunk-all': 'транк, все VLAN',
  none: 'VLAN не назначен',
  disabled: 'отключён',
};

export default function PortMap({ mag, sw }) {
  const [open, setOpen] = useState(false);
  const [data, setData] = useState({ status: 'idle' });
  const [selected, setSelected] = useState(null);
  const [highlight, setHighlight] = useState(null);

  useEffect(() => {
    if (!open) return undefined;
    let cancelled = false;
    setData({ status: 'loading' });
    api.get(`/api/netbox/ports?mag=${encodeURIComponent(mag)}&sw=${encodeURIComponent(sw)}`)
      .then((result) => { if (!cancelled) setData({ status: 'ready', ...result }); })
      .catch((e) => { if (!cancelled) setData({ status: 'error', message: e.message, code: e.status }); });
    return () => { cancelled = true; };
  }, [open, mag, sw]);

  const ports = data.ports || [];
  const layout = useMemo(() => groupPorts(ports), [ports]);
  const summary = useMemo(() => summarizeVlans(ports), [ports]);
  const selectedPort = ports.find((p) => p.name === selected) || null;
  const noVlansAtAll = ports.length > 0 && summary.vlans.length === 0;

  return (
    <div>
      <div className={styles.head}>
        <span className={styles.title}>Порты и VLAN</span>
        <button className={styles.toggle} onClick={() => setOpen((v) => !v)}>
          {open ? 'Скрыть' : 'Показать'}
        </button>
      </div>

      {open && data.status === 'loading' && <div className={styles.note}>Запрашиваю порты в NetBox…</div>}

      {open && data.status === 'error' && (
        <div className={styles.note}>
          {data.code === 503
            ? 'Сведения о портах берутся из NetBox — обмен с ним не настроен на сервере.'
            : data.message}
        </div>
      )}

      {open && data.status === 'ready' && !data.found && (
        <div className={styles.note}>
          Коммутатор не найден в NetBox. Его можно завести через «Отправить в NetBox» → «Новые устройства».
        </div>
      )}

      {open && data.status === 'ready' && data.found && ports.length === 0 && (
        <div className={styles.note}>В NetBox у коммутатора не заведены интерфейсы.</div>
      )}

      {open && data.status === 'ready' && data.found && ports.length > 0 && (
        <>
          {/* Пометка заметная намеренно: выдуманную конфигурацию нельзя
              принять за настоящую и пойти по ней что-то перенастраивать */}
          {data.demo && (
            <div className={styles.demo}>
              <b>Демонстрационные данные.</b> Сгенерированы для показа работы панели
              и не отражают настройки коммутатора.
            </div>
          )}

          {noVlansAtAll && (
            <div className={styles.note}>
              Интерфейсы в NetBox есть, но VLAN на них не назначены — панель показывает только состояние портов.
            </div>
          )}

          <div className={styles.faceplate}>
            {layout.groups.map((group) => (
              <div className={styles.group} key={group.key}>
                <div className={styles.groupLabel}>{group.label}</div>
                <div className={`${styles.grid} ${group.ports.length <= 4 ? styles.oneRow : ''}`}>
                  {group.ports.map((port) => {
                    const state = portState(port);
                    const dimmed = highlight != null && !portCarriesVlan(port, highlight);
                    const style = state === 'access' ? { background: vlanColor(port.untagged.vid) } : undefined;
                    return (
                      <button
                        key={port.name}
                        className={[
                          styles.port, styles[stateClass(state)],
                          dimmed ? styles.dimmed : '', selected === port.name ? styles.selected : '',
                        ].join(' ')}
                        style={style}
                        onClick={() => setSelected(selected === port.name ? null : port.name)}
                        title={`${port.name} — ${STATE_TEXT[state]}` +
                          (port.untagged ? `, VLAN ${port.untagged.vid}` : '') +
                          (port.description ? `\n${port.description}` : '')}
                      >
                        {splitPortName(port.name).index}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          {selectedPort && <PortDetails port={selectedPort} />}

          <div className={styles.legend}>
            {summary.vlans.map((v) => (
              <button
                key={v.vid}
                className={`${styles.chip} ${highlight === v.vid ? styles.chipActive : ''}`}
                onClick={() => setHighlight(highlight === v.vid ? null : v.vid)}
                title="Подсветить порты этого VLAN"
              >
                <span className={styles.swatch} style={{ background: vlanColor(v.vid) }} />
                <b>{v.vid}</b>{v.name ? ` ${v.name}` : ''}
                <span className={styles.chipCount}>
                  {v.access}{v.tagged ? ` + ${v.tagged} в транке` : ''}
                </span>
              </button>
            ))}
          </div>

          <div className={styles.totals}>
            Доступ: {summary.totals.access} · Транк: {summary.totals.trunk} ·
            Без VLAN: {summary.totals.none} · Отключено: {summary.totals.disabled}
            {data.netboxUrl && (
              <> · <a href={data.netboxUrl} target="_blank" rel="noreferrer">Открыть в NetBox</a></>
            )}
          </div>

          {layout.logical.length > 0 && (
            <details className={styles.logical}>
              <summary>Логические и служебные интерфейсы ({layout.logical.length})</summary>
              {layout.logical.map((p) => (
                <div key={p.name} className={styles.logicalRow}>
                  <span className={styles.mono}>{p.name}</span>
                  {p.description && <span> — {p.description}</span>}
                  {p.untagged && <span> · VLAN {p.untagged.vid}</span>}
                </div>
              ))}
            </details>
          )}
        </>
      )}
    </div>
  );
}

function stateClass(state) {
  return { access: 'access', trunk: 'trunk', 'trunk-all': 'trunkAll', none: 'none', disabled: 'disabled' }[state];
}

function PortDetails({ port }) {
  const state = portState(port);
  return (
    <div className={styles.details}>
      <div className={styles.detailsName}>{port.name}</div>
      <Row label="Состояние" value={STATE_TEXT[state]} />
      {port.description && <Row label="Описание" value={port.description} />}
      {port.untagged && (
        <Row label={state === 'access' ? 'VLAN' : 'VLAN без тега'}
             value={`${port.untagged.vid}${port.untagged.name ? ' — ' + port.untagged.name : ''}`} />
      )}
      {state === 'trunk-all' && <Row label="Тегированные" value="все VLAN" />}
      {port.tagged && port.tagged.length > 0 && (
        <Row label="Тегированные" value={port.tagged.map((v) => v.vid).join(', ')} />
      )}
      {port.lag && <Row label="Агрегация" value={port.lag} />}
      <Row label="Подключено" value={port.peer || 'не указано в NetBox'} />
    </div>
  );
}

function Row({ label, value }) {
  return (
    <div className={styles.row}>
      <span className={styles.rowLabel}>{label}</span>
      <span>{value}</span>
    </div>
  );
}
