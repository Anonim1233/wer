/**
 * Дивизион объекта: показ и назначение.
 *
 * Дивизион определяет зону ответственности, поэтому менять его может
 * только «разработчик» без ограничения по зоне — та же проверка, что
 * на сервере. Остальным показывается просто название.
 */
import { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';

import {
  selectDivisions, selectDivisionOfMag, selectCanManageDivisions,
  assignMagToDivision, createDivision,
} from '../../store/slices/divisionsSlice';

// Значение пункта «новый дивизион» — не может совпасть с названием,
// потому что названия не начинаются с двойного подчёркивания.
const NEW_DIVISION = '__new__';
import styles from './DivisionPicker.module.css';

export default function DivisionPicker({ mag }) {
  const dispatch = useDispatch();
  const divisions = useSelector(selectDivisions);
  const current = useSelector((state) => selectDivisionOfMag(state, mag));
  const canManage = useSelector(selectCanManageDivisions);

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const names = Object.keys(divisions).sort();

  // Без права управления — только показ, и лишь когда дивизион назначен:
  // пустая подпись в панели только занимала бы место.
  if (!canManage) {
    return current ? <span className={styles.plain}>{current}</span> : null;
  }

  async function handleChange(value) {
    let division = value || null;

    // Новый дивизион заводится прямо отсюда и сразу назначается объекту:
    // иначе при пустом справочнике выбирать было бы не из чего.
    if (value === NEW_DIVISION) {
      const name = (window.prompt('Название нового дивизиона') || '').trim();
      if (!name) return;
      division = name;
    }

    setSaving(true);
    setError(null);
    try {
      if (value === NEW_DIVISION && !divisions[division]) {
        await dispatch(createDivision(division)).unwrap();
      }
      await dispatch(assignMagToDivision({ mag, division })).unwrap();
    } catch (message) {
      setError(String(message));
    } finally {
      setSaving(false);
    }
  }

  return (
    <span className={styles.wrap}>
      <select
        className={`${styles.select} ${current ? '' : styles.unset}`}
        value={current ?? ''}
        onChange={(e) => handleChange(e.target.value)}
        disabled={saving}
        title="Дивизион объекта"
      >
        <option value="">Без дивизиона</option>
        {names.map((name) => (
          <option key={name} value={name}>{name}</option>
        ))}
        <option value={NEW_DIVISION}>+ Новый дивизион…</option>
      </select>

      {saving && <span className={styles.hint}>сохраняю…</span>}
      {error && <span className={styles.error} title={error}>не сохранилось</span>}
    </span>
  );
}
