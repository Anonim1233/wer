/**
 * Разбор выгрузки с коммутаторами.
 *
 * Файл читается в браузере, на сервер уходит уже разобранная
 * структура — так же, как в прежней версии.
 */

/** Соответствие колонок файла и полей, которые принимает сервер. */
const FIELD_MAP = {
  'Mag': 'mag',
  'Коммутатор': 'sw',
  'Шкаф': 'shkaf',
  'IP Коммутатора': 'ip',
  'UP': 'up',
  'DOWN': 'down',
  'Расположение': 'location',
  'SN Netbox': 'sn_netbox',
  'SN Lyra': 'sn_lyra',
  'Модель SW': 'model',
  'Комментарий': 'comment',
  '_Комментарий_Лира': 'comment_lyra',
};

/**
 * Сопоставляет названия колонок файла с ожидаемыми.
 *
 * В реальных выгрузках названия приходят с лишними пробелами, в другом
 * регистре или с неразрывным пробелом вместо обычного. Точное сравнение
 * отбрасывало бы такие файлы целиком, хотя данные в них правильные.
 */
function normalizeHeader(name) {
  return String(name)
    .replace(/\u00A0/g, ' ')   // неразрывный пробел приходит из некоторых выгрузок
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ');
}

/** Соответствие «приведённое название → поле запроса». */
const HEADER_LOOKUP = Object.fromEntries(
  Object.entries(FIELD_MAP).map(([column, field]) => [normalizeHeader(column), field])
);

/**
 * Находит в строке значение нужной колонки, сравнивая названия
 * с точностью до пробелов и регистра.
 */
function pickValue(row, field) {
  for (const [key, value] of Object.entries(row)) {
    if (HEADER_LOOKUP[normalizeHeader(key)] === field) return value;
  }
  return undefined;
}

/**
 * Какие из ожидаемых колонок найдены в файле.
 * Используется для понятного сообщения, если разбор не удался.
 */
export function detectColumns(rows) {
  if (!rows.length) return { found: [], missing: Object.keys(FIELD_MAP) };
  const present = new Set(Object.keys(rows[0]).map(normalizeHeader));
  const found = [];
  const missing = [];
  for (const column of Object.keys(FIELD_MAP)) {
    (present.has(normalizeHeader(column)) ? found : missing).push(column);
  }
  return { found, missing, actual: Object.keys(rows[0]) };
}

/**
 * Приводит строки выгрузки к виду, который принимает сервер.
 *
 * Записи без объекта или имени коммутатора отбрасываются: по ним
 * невозможно определить, что именно обновлять.
 */
export function prepareSwitchRows(rows) {
  const prepared = [];
  let skipped = 0;

  for (const row of rows) {
    const mag = String(pickValue(row, 'mag') ?? '').trim();
    const sw = String(pickValue(row, 'sw') ?? '').trim();

    if (!mag || !sw) {
      skipped++;
      continue;
    }

    const item = {};
    for (const field of Object.values(FIELD_MAP)) {
      const value = pickValue(row, field);
      item[field] = value != null ? String(value).trim() : '';
    }

    prepared.push(item);
  }

  return { rows: prepared, skipped };
}

/**
 * Сверка выгрузки NetBox с учётом коммутаторов.
 *
 * Имена в двух системах могут отличаться разделителем перед номером:
 * в данных встречаются оба варианта — «DS253_66» и «DS253-67».
 * Поэтому перед сравнением обе стороны приводятся к единому виду.
 */
export function normalizeForCompare(value) {
  return String(value || '').trim().toLowerCase().replace(/[-\u2010-\u2015]/g, '_');
}

export function reconcileWithNetbox(netboxRows, switches) {
  const byName = new Map();
  for (const row of switches) {
    byName.set(normalizeForCompare(row['Коммутатор']), row);
  }

  const matched = [];
  const serialDiffers = [];
  const missingHere = [];
  const onlyInNetbox = [];
  const seen = new Set();

  for (const device of netboxRows) {
    const key = normalizeForCompare(device['Имя']);
    const ours = byName.get(key);

    if (!ours) {
      onlyInNetbox.push(device);
      continue;
    }

    seen.add(key);

    const netboxSerial = String(device['Серийный номер'] || '').trim();
    const ourSerial = String(ours['SN Netbox'] || '').trim();

    if (!netboxSerial) continue; /* в NetBox серийника нет — сверять нечего */

    if (!ourSerial) missingHere.push({ device, ours, serial: netboxSerial });
    else if (netboxSerial.toLowerCase() !== ourSerial.toLowerCase()) {
      serialDiffers.push({ device, ours, netboxSerial, ourSerial });
    } else matched.push({ device, ours });
  }

  const onlyOurs = switches.filter(
    (row) => !seen.has(normalizeForCompare(row['Коммутатор']))
  );

  return {
    netboxTotal: netboxRows.length,
    ourTotal: switches.length,
    matched,
    serialDiffers,
    missingHere,
    onlyInNetbox,
    onlyOurs,
  };
}
