/**
 * Срез состояния портов: разбор файла, подготовка к загрузке, оформление.
 *
 * Колонки — как в отчёте Power BI «Устройства на портах коммутаторов».
 * Шкаф и модель коммутатора из файла не берутся: они ведутся в учёте.
 */

/** Колонка файла → поле. Названия сравниваются без учёта регистра и пробелов. */
const COLUMNS = {
  mag: ['mag', 'объект', 'магазин'],
  sw: ['sw_name', 'коммутатор', 'switch', 'hostname'],
  sw_ip: ['sw_ip', 'ip коммутатора', 'ip'],
  port: ['порты', 'порт', 'port'],
  status: ['status', 'статус', 'статус порта'],
  speed: ['speed', 'скорость'],
  vlan: ['vlan'],
  macs: ['mac', 'macs', 'mac-адрес'],
  // «Chasis» — с опечаткой, как в отчёте; правильное написание тоже принимается
  chassis_type: ['chasis type', 'chassis type', 'тип'],
  manufacturer: ['manufacturer', 'производитель'],
  device_model: ['model', 'модель устройства'],
  machine_name: ['machine name', 'имя компьютера', 'имя пк'],
  primary_user: ['primary user ldap', 'primary user', 'пользователь'],
};

const normalizeHeader = (h) => String(h).replace(/\u00A0/g, ' ').trim().toLowerCase().replace(/\s+/g, ' ');

const LOOKUP = new Map();
for (const [field, names] of Object.entries(COLUMNS)) for (const n of names) LOOKUP.set(n, field);

/** Какие обязательные колонки нашлись — для понятного сообщения об ошибке. */
export function detectStatusColumns(rows) {
  const headers = rows.length ? Object.keys(rows[0]) : [];
  const fields = new Set(headers.map((h) => LOOKUP.get(normalizeHeader(h))).filter(Boolean));
  const required = ['sw', 'port', 'status'];
  return { headers, missing: required.filter((f) => !fields.has(f)) };
}

/**
 * Статус к одному из трёх. ADM — порт отключён администратором:
 * его стоит отличать от DOWN, где порт включён, но к нему ничего не подключено.
 */
export function normalizeStatus(value) {
  const v = String(value || '').trim().toUpperCase().replace(/[\s_-]+/g, ' ');
  if (v === 'UP') return 'UP';
  if (v === 'DOWN') return 'DOWN';
  if (['ADM', 'ADMIN DOWN', 'ADMINDOWN', 'ADM DOWN', 'DISABLED', 'SHUTDOWN'].includes(v)) return 'ADM';
  return null;
}

/**
 * Код объекта: «4» → «004». Excel превращает «004» в число 4, и без
 * дополнения нулями объект не совпал бы с учётом. Если колонки нет —
 * код берётся из имени коммутатора: MAG004_65 → 004.
 */
export function normalizeMag(mag, sw) {
  let m = String(mag ?? '').replace(/[\u200B-\u200D\uFEFF\s]/g, '');
  if (!m) {
    const fromName = String(sw || '').match(/^(?:MAG|DS)?0*?(\d+)[_-]/i);
    m = fromName ? fromName[1] : '';
  }
  return /^\d+$/.test(m) ? m.padStart(3, '0') : m;
}

const MAC_RE = /^(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2}$|^[0-9a-f]{4}\.[0-9a-f]{4}\.[0-9a-f]{4}$|^[0-9a-f]{12}$/i;

/**
 * MAC-адреса из ячейки. На одном порту их бывает несколько — за коммутатором
 * или IP-телефоном с компьютером. «no» в отчёте означает «нет».
 */
export function splitMacs(value) {
  return String(value || '')
    .split(/[\s,;]+/)
    .map((m) => m.trim().toLowerCase())
    .filter((m) => MAC_RE.test(m));
}

/** Строки файла → строки для сервера. */
export function prepareStatusRows(rawRows) {
  const rows = [];
  let skipped = 0;
  for (const raw of rawRows) {
    const r = {};
    for (const [key, value] of Object.entries(raw)) {
      const field = LOOKUP.get(normalizeHeader(key));
      if (field && r[field] === undefined) r[field] = value;
    }
    const sw = String(r.sw ?? '').trim();
    const port = parseInt(String(r.port ?? '').trim(), 10);
    const status = normalizeStatus(r.status);
    if (!sw || !Number.isInteger(port) || !status) { skipped++; continue; }

    const text = (v) => { const t = String(v ?? '').trim(); return t && t.toLowerCase() !== 'no' ? t : ''; };
    rows.push({
      mag: normalizeMag(r.mag, sw), sw, port, status,
      sw_ip: text(r.sw_ip), speed: text(r.speed), vlan: text(r.vlan),
      macs: splitMacs(r.macs).join(','),
      chassis_type: text(r.chassis_type), manufacturer: text(r.manufacturer),
      device_model: text(r.device_model), machine_name: text(r.machine_name),
      primary_user: text(r.primary_user),
    });
  }
  return { rows, skipped };
}

/**
 * Деление на части для загрузки — по границам коммутаторов. Сервер заменяет
 * порты каждого коммутатора из части целиком; разорви коммутатор между
 * частями — вторая часть удалила бы порты, записанные первой.
 */
export function chunkBySwitch(rows, maxRows = 2000) {
  const groups = new Map();
  for (const r of rows) {
    const key = `${r.mag}\u0000${r.sw}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(r);
  }
  const chunks = [];
  let current = [];
  for (const group of groups.values()) {
    if (current.length && current.length + group.length > maxRows) { chunks.push(current); current = []; }
    current.push(...group);
  }
  if (current.length) chunks.push(current);
  return chunks;
}

/** Подписи и оттенки статусов — одни для панели, таблиц и легенды. */
export const STATUS_META = {
  UP:   { label: 'Поднят',               short: 'UP',   tone: 'ok' },
  DOWN: { label: 'Не подключён',         short: 'DOWN', tone: 'idle' },
  ADM:  { label: 'Отключён администратором', short: 'ADM', tone: 'off' },
};

/** Загрузка коммутатора: доля поднятых портов. */
export const utilization = (s) => (s.total ? Math.round((s.up / s.total) * 100) : 0);
