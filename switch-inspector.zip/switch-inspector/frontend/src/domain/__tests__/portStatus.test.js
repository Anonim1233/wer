import { describe, it, expect } from 'vitest';
import {
  normalizeStatus, normalizeMag, splitMacs, prepareStatusRows, chunkBySwitch, detectStatusColumns,
} from '../portStatus';

describe('нормализация', () => {
  it('статусы', () => {
    expect(normalizeStatus('up')).toBe('UP');
    expect(normalizeStatus(' DOWN ')).toBe('DOWN');
    expect(normalizeStatus('ADM')).toBe('ADM');
    expect(normalizeStatus('admin down')).toBe('ADM');
    expect(normalizeStatus('что-то')).toBeNull();
  });
  it('код объекта дополняется нулями и берётся из имени', () => {
    expect(normalizeMag(4, 'MAG004_65')).toBe('004');
    expect(normalizeMag('', 'MAG004_65')).toBe('004');
    expect(normalizeMag('', 'DS253-72')).toBe('253');
    expect(normalizeMag('134', '')).toBe('134');
  });
  it('MAC: несколько в ячейке, «no» — пусто', () => {
    expect(splitMacs('00:17:c8:97:bb:12,00:e0:4c:6b:97:fd')).toHaveLength(2);
    expect(splitMacs('no')).toEqual([]);
    expect(splitMacs('00E04C6BB619')).toEqual(['00e04c6bb619']);
  });
});

describe('разбор файла', () => {
  const raw = [
    { Mag: '004', 'Шкаф': 'Серверная', sw_name: 'MAG004_65', sw_ip: '10.81.16.65', 'Порты': 21, Status: 'ADM', Speed: 'auto', Vlan: 11, Mac: 'no' },
    { Mag: '004', sw_name: 'MAG004_65', 'Порты': 27, Status: 'UP', Vlan: 11, Mac: '04:7c:16:46:b3:14',
      'Chasis Type': 'Desktop', Manufacturer: 'Micro-Star', Model: 'Cubi N', 'Machine Name': 'S004W079', 'Primary User LDAP': 'ru1000\\x' },
    { sw_name: '', 'Порты': 1, Status: 'UP' },
  ];
  const { rows, skipped } = prepareStatusRows(raw);
  it('колонки отчёта распознаются', () => {
    expect(rows[1]).toMatchObject({ mag: '004', sw: 'MAG004_65', port: 27, status: 'UP', vlan: '11',
      chassis_type: 'Desktop', machine_name: 'S004W079', primary_user: 'ru1000\\x' });
  });
  it('«no» в MAC не попадает', () => { expect(rows[0].macs).toBe(''); });
  it('строка без коммутатора пропускается', () => { expect(skipped).toBe(1); });
  it('нехватка обязательных колонок видна', () => {
    expect(detectStatusColumns([{ foo: 1 }]).missing).toEqual(['sw', 'port', 'status']);
  });
});

describe('деление на части', () => {
  it('коммутатор не разрывается между частями', () => {
    const rows = [...Array(30)].map((_, i) => ({ mag: '004', sw: `SW${Math.floor(i / 10)}`, port: i }));
    const chunks = chunkBySwitch(rows, 15);
    for (const c of chunks) {
      const sws = new Set(c.map((r) => r.sw));
      for (const sw of sws) expect(c.filter((r) => r.sw === sw)).toHaveLength(10);
    }
  });
});
