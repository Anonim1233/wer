import { describe, it, expect } from 'vitest';
import {
  naturalCompare, splitPortName, shortGroupLabel, groupPorts,
  portState, vlanColor, portCarriesVlan, summarizeVlans,
} from '../ports';

const port = (name, extra = {}) => ({ name, type: '1000base-t', enabled: true, mode: 'access', tagged: [], ...extra });

describe('имена портов', () => {
  it('сортируются по номеру, а не как строки', () => {
    const names = ['Gi1/0/10', 'Gi1/0/2', 'Gi1/0/1'];
    expect(names.sort(naturalCompare)).toEqual(['Gi1/0/1', 'Gi1/0/2', 'Gi1/0/10']);
  });
  it('делятся на общую часть и номер', () => {
    expect(splitPortName('GigabitEthernet1/0/12')).toEqual({ prefix: 'GigabitEthernet1/0/', index: 12 });
  });
  it('подпись группы сокращается', () => {
    expect(shortGroupLabel('GigabitEthernet1/0/')).toBe('Gi1/0');
    expect(shortGroupLabel('TenGigabitEthernet1/1/')).toBe('Te1/1');
  });
});

describe('раскладка', () => {
  const ports = [
    port('GigabitEthernet2/0/1'), port('GigabitEthernet1/0/2'), port('GigabitEthernet1/0/1'),
    port('TenGigabitEthernet1/1/1', { type: '10gbase-x-sfpp' }),
    port('Port-channel1', { type: 'lag' }), port('Vlan10', { type: 'virtual' }),
    port('mgmt0', { mgmtOnly: true }),
  ];
  const { groups, logical } = groupPorts(ports);

  it('участники стека и модуль аплинков — отдельные группы', () => {
    expect(groups.map((g) => g.label)).toEqual(['Gi1/0', 'Gi2/0', 'Te1/1']);
  });
  it('порты внутри группы по порядку', () => {
    expect(groups[0].ports.map((p) => p.name)).toEqual(['GigabitEthernet1/0/1', 'GigabitEthernet1/0/2']);
  });
  it('логические и служебные — не на панели', () => {
    expect(logical.map((p) => p.name)).toEqual(['mgmt0', 'Port-channel1', 'Vlan10']);
  });
});

describe('состояние и VLAN', () => {
  it('состояния порта', () => {
    expect(portState(port('a', { untagged: { vid: 10 } }))).toBe('access');
    expect(portState(port('a', { mode: 'tagged' }))).toBe('trunk');
    expect(portState(port('a', { mode: 'tagged-all' }))).toBe('trunk-all');
    expect(portState(port('a', { mode: null }))).toBe('none');
    expect(portState(port('a', { enabled: false, untagged: { vid: 10 } }))).toBe('disabled');
  });
  it('цвет VLAN одинаков везде и различается у соседних номеров', () => {
    expect(vlanColor(10)).toBe(vlanColor(10));
    expect(vlanColor(10)).not.toBe(vlanColor(11));
  });
  it('VLAN проходит через порт без тега, в транке и при «все VLAN»', () => {
    expect(portCarriesVlan(port('a', { untagged: { vid: 10 } }), 10)).toBe(true);
    expect(portCarriesVlan(port('a', { mode: 'tagged', tagged: [{ vid: 20 }] }), 20)).toBe(true);
    expect(portCarriesVlan(port('a', { mode: 'tagged-all' }), 999)).toBe(true);
    expect(portCarriesVlan(port('a', { enabled: false, untagged: { vid: 10 } }), 10)).toBe(false);
  });
  it('легенда считает порты по VLAN', () => {
    const { vlans, totals } = summarizeVlans([
      port('1', { untagged: { vid: 10, name: 'Касса' } }),
      port('2', { untagged: { vid: 10, name: 'Касса' } }),
      port('3', { mode: 'tagged', untagged: { vid: 1, name: 'native' }, tagged: [{ vid: 10, name: 'Касса' }, { vid: 20, name: 'Wi-Fi' }] }),
      port('4', { mode: null }),
      port('5', { enabled: false }),
    ]);
    expect(vlans.find((v) => v.vid === 10)).toMatchObject({ access: 2, tagged: 1 });
    expect(totals).toEqual({ access: 2, trunk: 1, none: 1, disabled: 1 });
  });
});
