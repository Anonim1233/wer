/**
 * Порты коммутатора и VLAN: раскладка, состояние, цвета.
 *
 * Чистые функции без привязки к интерфейсу. На вход — порты в виде,
 * который отдаёт сервер из интерфейсов NetBox.
 */

/** Логические и служебные интерфейсы на лицевой панели не рисуются. */
const LOGICAL_TYPES = new Set(['virtual', 'lag', 'bridge']);

export const isPhysical = (port) => !LOGICAL_TYPES.has(port.type) && !port.mgmtOnly;

/**
 * Имя порта — общая часть и номер: «GigabitEthernet1/0/12» →
 * { prefix: 'GigabitEthernet1/0/', index: 12 }.
 */
export function splitPortName(name) {
  const m = String(name || '').match(/^(.*?)(\d+)$/);
  return m ? { prefix: m[1], index: Number(m[2]) } : { prefix: String(name || ''), index: 0 };
}

/**
 * Сравнение имён «по-человечески»: Gi1/0/2 раньше Gi1/0/10.
 * Обычное строковое сравнение поставило бы 10 перед 2.
 */
export function naturalCompare(a, b) {
  const pa = String(a).split(/(\d+)/);
  const pb = String(b).split(/(\d+)/);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = pa[i] ?? '';
    const y = pb[i] ?? '';
    if (x === y) continue;
    const nx = Number(x);
    const ny = Number(y);
    if (x !== '' && y !== '' && !Number.isNaN(nx) && !Number.isNaN(ny)) return nx - ny;
    // Текст — без учёта регистра: иначе Port-channel1 встал бы раньше
    // mgmt0, потому что заглавные буквы идут раньше строчных
    const byText = x.localeCompare(y, 'en', { sensitivity: 'base' });
    if (byText !== 0) return byText;
    return x < y ? -1 : 1;
  }
  return 0;
}

const SHORT_NAMES = [
  ['TwentyFiveGigE', 'Twe'], ['HundredGigE', 'Hu'], ['FortyGigabitEthernet', 'Fo'],
  ['TenGigabitEthernet', 'Te'], ['GigabitEthernet', 'Gi'], ['FastEthernet', 'Fa'], ['Ethernet', 'Eth'],
];

/** Короткая подпись группы: «GigabitEthernet1/0/» → «Gi1/0». */
export function shortGroupLabel(prefix) {
  let label = prefix;
  for (const [full, short] of SHORT_NAMES) {
    if (label.startsWith(full)) { label = short + label.slice(full.length); break; }
  }
  return label.replace(/[/:.-]$/, '') || prefix;
}

/**
 * Раскладка физических портов по группам — по модулю или участнику стека.
 * Gi1/0/* и Gi2/0/* — разные коммутаторы стека, Te1/1/* — модуль
 * аплинков; на панели это отдельные блоки, как на самом оборудовании.
 */
export function groupPorts(ports) {
  const groups = new Map();
  const logical = [];
  for (const port of ports) {
    if (!isPhysical(port)) { logical.push(port); continue; }
    const { prefix } = splitPortName(port.name);
    if (!groups.has(prefix)) groups.set(prefix, []);
    groups.get(prefix).push(port);
  }
  return {
    groups: [...groups.entries()]
      .sort(([a], [b]) => naturalCompare(a, b))
      .map(([prefix, list]) => ({
        key: prefix,
        label: shortGroupLabel(prefix),
        ports: list.sort((a, b) => naturalCompare(a.name, b.name)),
      })),
    logical: logical.sort((a, b) => naturalCompare(a.name, b.name)),
  };
}

/** Состояние порта для отображения. */
export function portState(port) {
  if (!port.enabled) return 'disabled';
  if (port.mode === 'tagged-all') return 'trunk-all';
  if (port.mode === 'tagged') return 'trunk';
  if (port.untagged) return 'access';
  return 'none';
}

/**
 * Цвет VLAN вычисляется из номера, а не назначается по порядку:
 * тогда VLAN 10 одного цвета на всех коммутаторах сети и узнаётся
 * сразу. Шаг по кругу оттенков — «золотой угол», чтобы соседние
 * номера получали непохожие цвета.
 */
const LIGHTNESS = [44, 56, 34];

export function vlanColor(vid) {
  const n = Number(vid);
  const hue = Math.round((n * 137.508) % 360);
  // Оттенков всего 360, и у далёких номеров они могут почти совпасть
  // (VLAN 11 и 100 — 73° и 71°). Яркость, вычисляемая из того же номера,
  // разводит такие пары.
  return `hsl(${hue} 58% ${LIGHTNESS[n % LIGHTNESS.length]}%)`;
}

/** Проходит ли VLAN через порт — без тега или в транке. */
export function portCarriesVlan(port, vid) {
  if (!port.enabled) return false;
  if (port.mode === 'tagged-all') return true;
  if (port.untagged && port.untagged.vid === vid) return true;
  return (port.tagged || []).some((v) => v && v.vid === vid);
}

/**
 * Легенда: какие VLAN есть на коммутаторе и сколько портов в каждом.
 * Считаются только физические порты — то, что видно на панели.
 */
export function summarizeVlans(ports) {
  const vlans = new Map();
  const totals = { access: 0, trunk: 0, none: 0, disabled: 0 };

  const touch = (v) => {
    if (!vlans.has(v.vid)) vlans.set(v.vid, { vid: v.vid, name: v.name, access: 0, tagged: 0 });
    return vlans.get(v.vid);
  };

  for (const port of ports.filter(isPhysical)) {
    const state = portState(port);
    if (state === 'disabled') { totals.disabled++; continue; }
    if (state === 'none') { totals.none++; continue; }
    if (state === 'access') { totals.access++; touch(port.untagged).access++; continue; }
    totals.trunk++;
    if (port.untagged) touch(port.untagged).tagged++;
    for (const v of port.tagged || []) if (v) touch(v).tagged++;
  }

  return { vlans: [...vlans.values()].sort((a, b) => a.vid - b.vid), totals };
}
