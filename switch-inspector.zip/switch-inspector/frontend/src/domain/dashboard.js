/**
 * Расчёты для главной страницы.
 *
 * Чистые функции без привязки к интерфейсу: на вход — записи
 * коммутаторов с подсчитанными замечаниями (_issues), на выход —
 * то, что показывает страница.
 */
import { ISSUE_DEFS } from './issues';
import { percent } from './divisions';

/**
 * Показатели верхней строки.
 *
 * Оттенок подсвечивает то, что требует внимания: замечания — жёлтым,
 * низкую заполненность — красным. Пороги те же, что в прежней версии:
 * ниже 80% — красный, ниже 95% — жёлтый.
 */
export function getDashboardTotals(rows, grouped) {
  const total = rows.length;
  const withIssues = rows.filter((r) => r._issues > 0).length;
  const objects = Object.keys(grouped).length;
  const objectsWithIssues = Object.values(grouped)
    .filter((group) => group.some((r) => r._issues > 0)).length;
  const clean = total - withIssues;
  const completion = percent(clean, total);

  return [
    { label: 'Всего коммутаторов', value: total },
    { label: 'Объектов', value: objects },
    { label: 'С замечаниями', value: withIssues, tone: withIssues ? 'warn' : null },
    { label: 'Без замечаний', value: clean },
    { label: 'Объектов с проблемами', value: objectsWithIssues, tone: objectsWithIssues ? 'warn' : null },
    {
      label: 'Заполненность',
      value: `${completion}%`,
      tone: completion < 80 ? 'err' : completion < 95 ? 'warn' : null,
    },
  ];
}

/**
 * Число записей по каждой категории замечаний.
 *
 * Доля считается от всех коммутаторов, а не от проблемных: так видно,
 * какая часть сети затронута, а не как замечания распределены между собой.
 */
export function getIssueCounts(rows) {
  return ISSUE_DEFS.map((def) => {
    const count = rows.filter(def.test).length;
    return {
      key: def.key,
      label: def.label,
      color: def.color,
      count,
      percent: percent(count, rows.length),
    };
  });
}

/**
 * Проблемные записи для таблицы: только с замечаниями, с отбором
 * по категории и поиском по всем полям записи.
 *
 * Отбор 'all' — все категории; так же он выглядит в состоянии
 * интерфейса по умолчанию и после повторного нажатия на карточку.
 */
export function filterProblemRows(rows, filterKey, search) {
  let result = rows.filter((r) => r._issues > 0);

  if (filterKey && filterKey !== 'all') {
    const def = ISSUE_DEFS.find((d) => d.key === filterKey);
    if (def) result = result.filter(def.test);
  }

  const query = String(search || '').trim().toLowerCase();
  if (query) {
    result = result.filter((r) =>
      Object.values(r).some((v) => String(v ?? '').toLowerCase().includes(query))
    );
  }

  return result;
}

/**
 * Ход обработки замечаний: сколько проблемных записей уже отмечено
 * как обработанные, и по каким объектам осталось больше всего.
 *
 * Отвечает на вопрос «за что браться дальше»: объекты упорядочены
 * по числу НЕобработанных записей, а не по общему числу замечаний.
 */
export function getProgressStats(rows, grouped, isProcessed) {
  const withIssues = rows.filter((r) => r._issues > 0);
  const total = withIssues.length;

  if (!total) {
    return { total: 0, done: 0, percent: 100, objects: [] };
  }

  const done = withIssues.filter((r) => isProcessed(r['Mag'], r['Коммутатор'])).length;

  const objects = Object.entries(grouped)
    .map(([mag, group]) => {
      const problems = group.filter((r) => r._issues > 0);
      const processed = problems.filter((r) => isProcessed(mag, r['Коммутатор'])).length;
      return {
        mag,
        total: problems.length,
        done: processed,
        remaining: problems.length - processed,
      };
    })
    .filter((x) => x.total > 0)
    .sort((a, b) => b.remaining - a.remaining);

  return { total, done, percent: percent(done, total), objects };
}

/**
 * Статистика по моделям оборудования.
 *
 * Помимо количества считается число объектов: одна и та же модель
 * может стоять в одном месте сотней штук или быть распределена
 * по всей сети — это разные ситуации при планировании замены.
 */
export function getModelStats(rows) {
  const map = new Map();

  for (const row of rows) {
    const model = (row['Модель SW'] || 'Не указана').trim();
    if (!map.has(model)) map.set(model, { count: 0, objects: new Set() });
    const entry = map.get(model);
    entry.count += 1;
    if (row['Mag']) entry.objects.add(row['Mag']);
  }

  const total = rows.length;
  return [...map.entries()]
    .map(([model, data]) => ({
      model,
      count: data.count,
      objectCount: data.objects.size,
      share: percent(data.count, total),
    }))
    .sort((a, b) => b.count - a.count);
}

/** Утилизация портов по объектам — от самых загруженных. */
