/**
 * Загрузка среза портов из файла — выгрузки отчёта «Устройства на портах
 * коммутаторов» в Excel или CSV.
 *
 * Файл отправляется частями по границам коммутаторов: по всей сети это
 * десятки тысяч строк, одним запросом их не передать. Ход загрузки виден.
 */
import { useState } from 'react';
import * as XLSX from 'xlsx';
import { api } from '../../api/client';
import { sanitizeParsed, checkFileSize } from '../../domain/safeParse';
import { prepareStatusRows, chunkBySwitch, detectStatusColumns } from '../../domain/portStatus';

export function usePortsImport(onDone) {
  const [state, setState] = useState({ status: 'idle' });

  async function importFile(file, snapshotDate) {
    const sizeError = checkFileSize(file);
    if (sizeError) { setState({ status: 'error', message: sizeError }); return; }

    setState({ status: 'reading', message: 'Читаю файл…' });
    let prepared;
    try {
      const workbook = XLSX.read(await file.arrayBuffer(), { type: 'array' });
      // Данные ищутся на всех листах: в выгрузках бывает титульный лист
      let raw = [];
      for (const name of workbook.SheetNames) {
        const rows = sanitizeParsed(XLSX.utils.sheet_to_json(workbook.Sheets[name], { defval: '' }));
        if (rows.length && detectStatusColumns(rows).missing.length === 0) { raw = rows; break; }
        if (!raw.length) raw = rows;
      }
      const columns = detectStatusColumns(raw);
      if (columns.missing.length) {
        const names = { sw: 'sw_name', port: 'Порты', status: 'Status' };
        setState({
          status: 'error',
          message: `Не найдены колонки: ${columns.missing.map((f) => `«${names[f]}»`).join(', ')}. ` +
            (columns.headers.length ? `В файле: ${columns.headers.slice(0, 12).join(', ')}.` : 'Файл пуст.'),
        });
        return;
      }
      prepared = prepareStatusRows(raw);
    } catch {
      setState({ status: 'error', message: 'Не удалось прочитать файл.' });
      return;
    }

    if (!prepared.rows.length) {
      setState({ status: 'error', message: 'В файле нет строк с коммутатором, портом и статусом.' });
      return;
    }

    const chunks = chunkBySwitch(prepared.rows);
    const total = { imported: 0, switches: 0, skippedOutOfScope: 0, skippedInvalid: prepared.skipped, merged: 0 };
    try {
      for (let i = 0; i < chunks.length; i++) {
        setState({ status: 'uploading', progress: Math.round((i / chunks.length) * 100),
          message: `Загружаю: часть ${i + 1} из ${chunks.length}` });
        const result = await api.post('/api/ports/import', {
          rows: chunks[i], snapshotDate, chunk: `${i + 1}/${chunks.length}`,
        });
        total.imported += result.imported;
        total.switches += result.switches;
        total.skippedOutOfScope += result.skippedOutOfScope;
        total.skippedInvalid += result.skippedInvalid;
        total.merged += result.mergedDuplicates || 0;
      }
    } catch (e) {
      // Уже загруженные части остаются: каждая заменяет только свои коммутаторы
      setState({ status: 'error', message: `${e.message}. Загружено до сбоя: ${total.imported} портов.` });
      onDone?.();
      return;
    }

    const notes = [];
    // Несколько строк на один порт — по строке на устройство — сведены в одну
    if (total.merged) notes.push(`объединено строк одного порта: ${total.merged}`);
    if (total.skippedOutOfScope) notes.push(`вне вашей зоны: ${total.skippedOutOfScope}`);
    if (total.skippedInvalid) notes.push(`с ошибками: ${total.skippedInvalid}`);
    setState({
      status: 'done',
      message: `Загружено ${total.imported} портов на ${total.switches} коммутаторах` +
        (notes.length ? `; пропущено — ${notes.join(', ')}` : '') + '.',
    });
    onDone?.();
  }

  return { state, importFile, reset: () => setState({ status: 'idle' }) };
}
